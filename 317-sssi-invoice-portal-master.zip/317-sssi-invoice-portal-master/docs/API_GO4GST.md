# GO4GST API (SSSi Tool)

Machine API added for SSSi. **Web UI import/export is unchanged.**

Base URL (production example): `https://invoice.surugasystems.com`

Auth header on every call:

```http
X-API-Key: <value of GO4GST_API_KEY in server .env>
```

## Endpoints

### 1. Convert (recommended for SSSi) — atomic SOP flow

`POST /api/v1/go4gst/convert`

Same as manual: **clear buffer → import CSV → export 139-column template**.

- Body: `multipart/form-data`, field name `file` = 34-column UTF-8 CSV (MOSSIND_AR style)
- Success: `200` + CSV file (UTF-8 BOM), filename `GO4GST_139_<original>.csv`
- Headers on success: `X-GO4GST-Rows`, `X-GO4GST-ECAL`
- Errors: `401` bad key, `422` validation, `503` key not configured

API response applies SOP slide-14 fixes (product name ≤ 30 chars; document date from ship date). Web template download is unchanged.

### 2. Optional step endpoints (mirror UI buttons)

| Method | Path | Same as |
|--------|------|---------|
| `DELETE` | `/api/v1/go4gst/rows` | Clear all rows |
| `POST` | `/api/v1/go4gst/import` | Import CSV (append, no clear) |
| `GET` | `/api/v1/go4gst/export` | Export current buffer as 139 CSV |

## File-only test mode (no MySQL)

On the server (or local Laravel), set:

```env
GO4GST_API_KEY=your-secret
GO4GST_SKIP_DB=true
```

Then `POST /api/v1/go4gst/convert` still requires `X-API-Key`, validates CSV, builds 139 columns **in memory**, and **does not** touch `rst_excel_row_data`.

- `clear` / `import` / `export` return **503** while `GO4GST_SKIP_DB=true` (those endpoints need DB).
- Production: set `GO4GST_SKIP_DB=false` (or remove it). Convert again runs **clear → import → export** exactly like the web UI.

Workstation without PHP: use the Python stand-in (same URL path + header):

```bash
python "D:\SourceCode\SSSi document\_local_go4gst_api_server.py"
# then point SSSi Go4gstApiUrl to http://127.0.0.1:8766/api/v1/go4gst/convert
# Go4gstApiKey = test-key-local
```

## curl example

```bash
curl -X POST "https://invoice.surugasystems.com/api/v1/go4gst/convert" \
  -H "X-API-Key: YOUR_KEY" \
  -F "file=@GO4GST_SIPL_sample.csv;type=text/csv" \
  -o GO4GST_139_out.csv
```

## Server setup

1. Deploy this `develop` (or merged) branch.
2. Add to `.env`: `GO4GST_API_KEY=<long-random-secret>`
3. `php artisan config:clear` if config is cached.
4. Confirm web Import/Export still works with a browser login.

## Concurrent use warning

Buffer table `rst_excel_row_data` is shared. Convert clears the whole table (same as SOP clear-all). Do not run API convert while someone is mid-session on the web UI.
