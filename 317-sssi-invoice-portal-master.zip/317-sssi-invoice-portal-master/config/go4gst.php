<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Machine API settings for SSSi Tool
    |--------------------------------------------------------------------------
    |
    | Read through config() rather than env() so the endpoints keep working
    | after php artisan config:cache, which stops env() from seeing .env.
    |
    */

    'api_key' => env('GO4GST_API_KEY', ''),

    // true = convert in memory without touching rst_excel_row_data (file-only testing)
    'skip_db' => (bool) env('GO4GST_SKIP_DB', false),

    // seconds to wait for the rst_excel_row_data buffer lock
    'lock_timeout' => (int) env('GO4GST_LOCK_TIMEOUT', 15),

];
