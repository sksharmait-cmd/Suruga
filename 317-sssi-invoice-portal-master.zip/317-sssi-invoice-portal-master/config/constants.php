<?php
// artisan config:cache loads every file under config/ a second time and define() is not
// idempotent, so bail out if the constant is already in place.
if (defined('BUYER')) {
    return;
}

define('BUYER', [
    'H'=>[
        'gst'=>'06AAFCM9345Q1ZQ',
        'lname'=>'MISUMI INDIA PVT. LTD.',
        'tname'=>'MISUMI INDIA PVT. LTD.',
        'pos'=>'',
        'addr1'=>'PLOT NO - 31, ELECTRONIC CITY,SEC-18,',
        'addr2'=>'UDYOG VIHAR PHASE IV',
        'loc'=>'GURGAON, HARYANA',
        'pin'=>'122016',
        'state'=>'6',
        'phone'=>'1244688800',
        'email'=>'cs@misumi.co.in'
    ],
    'K'=>[
        'gst'=>'29AAFCM9345Q1ZI',
        'lname'=>'MISUMI INDIA PVT. LTD.',
        'tname'=>'MISUMI INDIA PVT. LTD.',
        'pos'=>'',
        'addr1'=>'SyNo.92(P),93(P),94(P),95(P),96(P)97(P)98(P)99(P)',
        'addr2'=>'Iggalur Village,Attibele Hobli,Anekal(Taluk),Bangalore Urban District Karnataka',
        'loc'=>'Karnataka',
        'pin'=>'562107',
        'state'=>'29',
        'phone'=>'1244688800',
        'email'=>'cs@misumi.co.in'
    ],
    'M'=>[
        'gst'=>'27AAFCM9345Q3ZK',
        'lname'=>'MISUMI INDIA PVT. LTD.',
        'tname'=>'MISUMI INDIA PVT. LTD.',
        'pos'=>'',
        'addr1'=>'Gate no. 98/3 Post Kuruli Taluka Khed',
        'addr2'=>'Murhe Vasti, District. Pune',
        'loc'=>'Maharastra',
        'pin'=>'410501',
        'state'=>'27',
        'phone'=>'1244688800',
        'email'=>'cs@misumi.co.in'
    ]
]);