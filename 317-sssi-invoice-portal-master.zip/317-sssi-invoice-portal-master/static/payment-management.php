<?php include 'header.php' ?>
<div id="accountPage"></div>
<div class="pcoded-content">
  <div class="pcoded-inner-content">
    <div class="main-body">
      <div class="page-wrapper">
        <div class="page-header card">
          <div class="row align-items-end">
            <div class="col-sm-6 col-lg-6">
              <div class="page-header-title d-flex">
                <i class="fa fa-usd bg-c-green"></i>
                <div class="d-inline">
                  <h4>Payment Management</h4>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-lg-6">
              <div class="page-header-breadcrumb">
                <div class="page-header-breadcrumb">
                  <ul class="breadcrumb-title">
                    <li class="breadcrumb-item">
                      <a href="dashboard.php">
                        <i class="icofont icofont-home"></i>
                      </a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Payment Management</a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="page-body">
          <div class="card">
            <div class="card-block">
              <div class="dt-plugin-buttons"></div>
              <!-- <div class="mb-4 m-b-15 topForm">
                <label class="d-flex text-dark pull-left mr-3">
                  From <input type="text" class="form-control ml-2 mr-2 wpx85" autocomplete="off" id="start_date"><i class="fa fa-calendar mt-1"></i>
                </label>
                <label class="d-flex text-dark pull-left ml-2 mr-3">
                  To <input type="text" class="form-control ml-2 mr-2 wpx85" autocomplete="off" id="end_date"><i class="fa fa-calendar mt-1"></i>
                </label>
              </div> -->
              <div class="row">
                <div class="col-12 col-sm-4 col-md-4 mb-3">
                  <button type="button" class="btn btn-success btn-md">Export</button>
                </div>
                <div class="col-12 col-sm-4 col-md-4 mb-3">
                  Total Payment Received: 900 USD
                </div>
              </div>
              <div class="dt-responsive table-responsive">
                <table id="account-list" class="table table-striped table-bordered nowrap m-0">
                  <thead>
                    <tr>
                      <th class="no-sort wpx-60">S.No</th>
                      <th>Transaction ID</th>
                      <th>User Name</th>
                      <th>Date and Time</th>
                      <th>Price</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>01</td>
                      <td>123</td>
                      <td>ABC</td>
                      <td>10-08-2019, 10:00 AM</td>
                      <td>900 USD</td>
                    </tr>
                  </tbody>
                  <tfoot>
                    <tr>
                      <th class="text-right" colspan="5">
                        Total Price: 3600 USD
                      </th>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div> 
<?php include'footer.php' ?>
<script type="text/javascript">
  $('#account-list').DataTable({
    columnDefs: [
      { targets: 'no-sort', orderable: false }
    ]
  });
</script>
<!-- add modal -->
<div id="add-modal" class="modal fade">
  <div class="modal-dialog modal-sm">
    <div class="modal-body">
      <h5>Add Podcast Category</h5>
      <form action="#">
        <div class="form-group">
          <label>Podcast Category Name</label>
          <input type="text" name="" class="form-control"/>
        </div>
        <div class="text-center">
          <button type="button" class="btn btn-sm btn-success mr-1" data-target="#add-sccess-modal" data-toggle="modal" data-dismiss="modal">Save</button>
          <button type="button" class="btn btn-sm btn-danger ml-1" data-dismiss="modal">Cancel</button>
        </div>
      </form>   
    </div>
  </div>
</div>
<!-- edit modal -->
<div id="edit-modal" class="modal fade">
  <div class="modal-dialog modal-sm">
    <div class="modal-body">
      <h5>Edit Podcast Category</h5>
      <form action="#">
        <div class="form-group">
          <label>Podcast Category Name</label>
          <input type="text" name="" class="form-control"/>
        </div>
        <div class="text-center">
          <button type="button" class="btn btn-sm btn-success mr-1" data-target="#edit-sccess-modal" data-toggle="modal" data-dismiss="modal">Save</button>
          <button type="button" class="btn btn-sm btn-danger ml-1" data-dismiss="modal">Cancel</button>
        </div>
      </form>   
    </div>
  </div>
</div>
<!-- block modal -->
<div id="block-modal" class="modal fade">
  <div class="modal-dialog modal-sm">
    <div class="modal-body text-center">
      <div class="row">
        <div class="col-md-12">
          <i class="text-success fs-34 d-inline-block ti-check mb-4"></i>
          <h6>Are you sure you want to block this podcast category?</h6>
        </div>
      </div>
      <hr />
      <div class="row m-t-15">
        <div class="col-sm-12">
          <button type="button" class="btn btn-sm btn-success mr-1" data-target="#block-sccess-modal" data-toggle="modal" data-dismiss="modal">Block</button>
          <button type="button" class="btn btn-sm btn-danger ml-1" data-dismiss="modal">Cancel</button>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- unblock modal -->
<div id="unblock-modal" class="modal fade">
  <div class="modal-dialog modal-sm">
    <div class="modal-body text-center">
      <div class="row">
        <div class="col-md-12">
          <i class="text-danger fs-34 d-inline-block ti-close mb-4"></i>
          <h6>Are you sure you want to unblock this podcast category? </h6>
        </div>
      </div>
      <hr />
      <div class="row m-t-15">
        <div class="col-sm-12">
          <button type="button" class="btn btn-sm btn-success mr-1" data-target="#unblock-sccess-modal" data-toggle="modal" data-dismiss="modal">Unblock</button>
          <button type="button" class="btn btn-sm btn-danger ml-1" data-dismiss="modal">Cancel</button>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- delete block -->
<div id="delete-modal" class="modal fade">
  <div class="modal-dialog modal-sm">
    <div class="modal-body text-center">
      <div class="row">
        <div class="col-md-12">
          <i class="text-info fs-34 d-inline-block ti-share mb-4"></i>
          <h6>Are you sure you want to delete this podcast category?</h6>
        </div>
      </div>
      <hr />
      <div class="row m-t-15">
        <div class="col-sm-12">
          <button type="button" class="btn btn-sm btn-success mr-1" data-target="#delete-sccess-modal" data-toggle="modal" data-dismiss="modal">Delete</button>
          <button type="button" class="btn btn-sm btn-danger ml-1" data-dismiss="modal">Cancel</button>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- success modal -->
<div id="block-sccess-modal" class="modal fade">
  <div class="modal-dialog modal-sm" data-dismiss="modal">
    <div class="modal-body text-center">
      <div class="row">
        <div class="col-md-12">
          <i class="text-warning fs-34 d-inline-block icofont icofont-check-circled mb-4"></i>
          <h6>Successfully Block</h6>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- success modal -->
<div id="unblock-sccess-modal" class="modal fade">
  <div class="modal-dialog modal-sm" data-dismiss="modal">
    <div class="modal-body text-center">
      <div class="row">
        <div class="col-md-12">
          <i class="text-success fs-34 d-inline-block icofont icofont-check-circled mb-4"></i>
          <h6>Successfully Unblock</h6>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- success modal -->
<div id="delete-sccess-modal" class="modal fade">
  <div class="modal-dialog modal-sm" data-dismiss="modal">
    <div class="modal-body text-center">
      <div class="row">
        <div class="col-md-12">
          <i class="text-danger fs-34 d-inline-block icofont icofont-check-circled mb-4"></i>
          <h6>Successfully Delete</h6>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- success modal -->
<div id="add-sccess-modal" class="modal fade">
  <div class="modal-dialog modal-sm" data-dismiss="modal">
    <div class="modal-body text-center">
      <div class="row">
        <div class="col-md-12">
          <i class="text-success fs-34 d-inline-block icofont icofont-check-circled mb-4"></i>
          <h6>Successfully Added</h6>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- success modal -->
<div id="edit-sccess-modal" class="modal fade">
  <div class="modal-dialog modal-sm" data-dismiss="modal">
    <div class="modal-body text-center">
      <div class="row">
        <div class="col-md-12">
          <i class="text-success fs-34 d-inline-block icofont icofont-check-circled mb-4"></i>
          <h6>Successfully Edited</h6>
        </div>
      </div>
    </div>
  </div>
</div>