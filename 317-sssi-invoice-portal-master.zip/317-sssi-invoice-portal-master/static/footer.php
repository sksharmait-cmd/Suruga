      </div>
    </div>
  </div>
</div>
  <script type="text/javascript" src="assets/js/jquery.min.js"></script>
  <!-- <script type="text/javascript" src="assets/js/jquery-ui.min.js"></script> -->
  <script type="text/javascript" src="assets/js/popper.min.js"></script>
  <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
  <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.7.1/js/bootstrap-datepicker.min.js"></script> -->
  
  <!-- <script type="text/javascript" src="assets/pages/widget/excanvas.js"></script> -->
  <!-- <script type="text/javascript" src="assets/js/jquery.slimscroll.js"></script> -->
  <!-- <script type="text/javascript" src="assets/js/jquery.easypiechart.min.js"></script> -->
  <!-- <script type="text/javascript" src="assets/js/counter.js"></script> -->
  <!-- <script type="text/javascript" src="assets/peity/js/jquery.peity.js"></script> -->
  <!-- <script type="text/javascript" src="assets/pages/widget/amchart/ammap.js"></script> -->
  <!-- <script type="text/javascript" src="assets/pages/chart/float/jquery.flot.js"></script> -->
  <script type="text/javascript" src="assets/js/Chart.js"></script>
  <!-- <script type="text/javascript" src="assets/lightbox2/js/lightbox.min.js"></script> -->
  <!-- <script type="text/javascript" src="assets/pages/advance-elements/moment-with-locales.min.js"></script> -->
  <!-- <script type="text/javascript" src="assets/pages/advance-elements/bootstrap-datetimepicker.min.js"></script> -->
  <!-- <script type="text/javascript" src="assets/bootstrap-daterangepicker/js/daterangepicker.js"></script> -->
  <!-- <script type="text/javascript" src="assets/datedropper/js/datedropper.min.js"></script> -->
  <script type="text/javascript" src="assets/js/owl.carousel.min.js"></script> 
  <script type="text/javascript" src="assets/js/iEdit.js"></script> 
  
  <script type="text/javascript" src="assets/js/jquery.dataTables.min.js"></script> 

  <!-- <script type="text/javascript" src="assets/js/switchery.min.js"></script>  -->
  <!-- <script type="text/javascript" src="assets/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script> -->
  <!-- <script type="text/javascript" src="assets/datatables.net-responsive/js/dataTables.responsive.min.js"></script> -->
  <!-- <script type="text/javascript" src="assets/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script> -->
  <!-- <script type="text/javascript" src="assets/pages/chart/echarts/js/echarts-all.js"></script> -->
  <!-- <script type="text/javascript" src="assets/pages/widget/jquery.sparkline.js"></script> -->
  <!-- <script type="text/javascript" src=" assets/pages/widget/amchart/amcharts.min.js"></script> -->
  <!-- <script type="text/javascript" src="assets/pages/widget/amchart/serial.min.js"></script>  -->
  <!-- <script type="text/javascript" src="assets/jquery.cookie/js/jquery.cookie.js"></script> -->
  <!-- <script type="text/javascript" src="assets/jquery.steps/js/jquery.steps.js"></script> -->
  <!-- <script type="text/javascript" src="assets/jquery-validation/js/jquery.validate.js"></script> -->
  <!-- <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/underscore.js/1.8.3/underscore-min.js"></script> -->
  <!-- <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script> -->
  <!-- <script type="text/javascript" src="assets/pages/form-validation/validate.js"></script> -->
  <!-- <script type="text/javascript" src="assets/js/i18next.min.js"></script> -->
  <!-- <script type="text/javascript" src="assets/js/i18nextXHRBackend.min.js"></script> -->
  <!-- <script type="text/javascript" src="assets/js/i18nextBrowserLanguageDetector.min.js"></script> -->
  <!-- <script type="text/javascript" src="assets/js/jquery-i18next.min.js"></script> -->
  <!-- <script type="text/javascript" src="assets/pages/chat/js/mmc-common.js"></script> -->
  <!-- <script type="text/javascript" src="assets/pages/chat/js/mmc-chat.js"></script> -->
  <!-- <script type="text/javascript" src="assets/pages/chat/js/chat.js"></script> -->
  <!-- <script type="text/javascript" src="assets/jquery-bar-rating/js/jquery.barrating.min.js"></script> -->
  <!-- <script type="text/javascript" src="assets/pages/rating/rating.js"></script> -->
  <!-- <script type="text/javascript" src="assets/slick-carousel/js/slick.min.js"></script> -->
  <!-- <script type="text/javascript" src="assets/pages/product-detail/product-detail.js"></script> -->
  <!-- <script type="text/javascript" src="assets/pages/isotope/jquery.isotope.js"></script> -->
  <!-- <script type="text/javascript" src="assets/pages/isotope/isotope.pkgd.min.js"></script> -->
  <!-- <script type="text/javascript" src="assets/pages/payment-card/card.js"></script> -->
  <!-- <script type="text/javascript" src="assets/pages/payment-card/jquery.payform.min.js" charset="utf-8"></script> -->
  <!-- <script type="text/javascript" src="assets/pages/dashboard/custom-dashboard.min.js"></script>  -->
  <!-- <script type="text/javascript" src="assets/pages/dashboard/ecommerce-dashboard.min.js"></script> -->
  <!-- <script type="text/javascript" src="assets/pages/dashboard/crm-dashboard.min.js"></script>  -->
  <!-- <script type="text/javascript" src="assets/pages/dashboard/analytic-dashboard.js"></script> -->
  <!-- <script type="text/javascript" src="assets/pages/user-profile.js"></script>  -->
  <!-- <script type="text/javascript" src="assets/pages/dashboard/project-dashboard.js"></script> -->
  <!-- <script type="text/javascript" src="assets/pages/widget/widget-advanced.min.js"></script> -->
  <!-- <script type="text/javascript" src="assets/pages/forms-wizard-validation/form-wizard.js"></script> -->
  <!-- <script type="text/javascript" src="assets/pages/data-table/js/data-table-custom.js"></script> -->
  <!-- <script type="text/javascript" src="assets/pages/message/message.js"></script> -->
  <!-- <script type="text/javascript" src="assets/pages/product-list/product-list.js"></script> -->
  <!-- <script type="text/javascript" src="assets/js/SmoothScroll.js"></script> -->

  <!-- email compose -->
<!-- <script type="text/javascript">
  lightbox.option({
    'resizeDuration': 200,
    'wrapAround': true
  })
</script> -->
<!-- <script type="text/javascript">
  $(window).on('load', function() {
      var $container = $('.filter-container');
      $container.isotope({
          filter: '*',
          animationOptions: {
              duration: 750,
              easing: 'linear',
              queue: false
          }
      });
      var $grid = $('.default-grid').isotope({
          itemSelector: '.default-grid-item',
          masonry: {}
      });
  });
</script> -->
  <!-- <script type="text/javascript" src="assets/js/demo-12.js"></script>  -->
  <!-- <script type="text/javascript" src="assets/js/jquery.mCustomScrollbar.concat.min.js"></script> -->
  <!-- <script type="text/javascript" src="assets/js/script.min.js"></script> -->
  <script type="text/javascript" src="assets/js/common-pages.js"></script> 

  <script type="text/javascript">
  
  $(document).on("change","#chooseImage",function(e2) {
    var img1 = e2.target.files[0];
    if(!iEdit.open(img1, true, function(res1){
      $("#imageFile").attr("src", res1);  
    })){
      alert("Whoops! That is not an image!");
    }
  });

  </script>
  
</body >
</html>
