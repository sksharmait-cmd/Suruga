<?php include 'header.php' ?>
<div id="accountPage"></div>
<div class="pcoded-content">
  <div class="pcoded-inner-content">
    <div class="main-body">
      <div class="page-wrapper">
        <div class="page-header card">
          <div class="row align-items-end">
            <div class="col-sm-6 col-lg-6">
              <div class="page-header-title d-flex">
                <i class="fa fa-envelope-o bg-c-green"></i>
                <div class="d-inline">
                  <h4>Email Management</h4>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-lg-6">
              <div class="page-header-breadcrumb">
                <div class="page-header-breadcrumb">
                  <ul class="breadcrumb-title">
                    <li class="breadcrumb-item">
                      <a href="dashboard.php">
                        <i class="icofont icofont-home"></i>
                      </a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Email Management</a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="page-body">
          <div class="card">
            <div class="card-block">
              <div class="dt-plugin-buttons"></div>
              <!-- <div class="mb-4 m-b-15 topForm">
                <label class="d-flex text-dark pull-left mr-3">
                  From <input type="text" class="form-control ml-2 mr-2 wpx85" autocomplete="off" id="start_date"><i class="fa fa-calendar mt-1"></i>
                </label>
                <label class="d-flex text-dark pull-left ml-2 mr-3">
                  To <input type="text" class="form-control ml-2 mr-2 wpx85" autocomplete="off" id="end_date"><i class="fa fa-calendar mt-1"></i>
                </label>
              </div> -->
              <div class="text-right m-b-15">
                <button class="btn btn-md btn-success" data-target="#send-modal" data-toggle="modal">Send Email</button>
              </div>
              <div class="dt-responsive table-responsive">
                <table id="account-list" class="table table-striped table-bordered nowrap m-0">
                  <thead>
                    <tr>
                      <th class="wpx-60 no-sort">S.No</th>
                      <th>From Email ID</th>
                      <th>To Email ID</th>
                      <th>Title</th>
                      <th>Description</th>
                      <th class="wpx-80 no-sort">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>01</td>
                      <td>anshu@gmail.com</td>
                      <td>anshu@gmail.com</td>
                      <td>Demo 1</td>
                      <td>Lorem ipsum is a dummy text</td>
                      <td>
                        <button data-toggle="modal" data-target="#delete-modal" class="btn btn-sm btn-danger"><i class="ti-trash"></i></button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div> 
<?php include'footer.php' ?>
<script type="text/javascript">
  $('#account-list').DataTable({
    columnDefs: [
      { targets: 'no-sort', orderable: false }
    ]
  });
</script>
<!-- add modal -->
<div id="send-modal" class="modal fade">
  <div class="modal-dialog modal-md">
    <div class="modal-body">
      <h5>Send Email</h5>
      <form action="#">
        <div class="form-group">
          <label>From</label>
          <input type="text" class="form-control"/>
        </div>
        <div class="form-group">
          <label>To</label>
          <input type="text" class="form-control"/>
        </div>
        <div class="form-group">
          <label>Title</label>
          <input type="text" class="form-control"/>
        </div>
        <div class="form-group">
          <label>Message</label>
          <textarea rows="5" class="form-control"></textarea>
        </div>
        <div class="text-center">
          <button type="button" class="btn btn-sm btn-success mr-1" data-target="#add-sccess-modal" data-toggle="modal" data-dismiss="modal">Save</button>
          <button type="button" class="btn btn-sm btn-danger ml-1" data-dismiss="modal">Cancel</button>
        </div>
      </form>   
    </div>
  </div>
</div>
<!-- unblock modal -->
<div id="delete-modal" class="modal fade">
  <div class="modal-dialog modal-sm">
    <div class="modal-body text-center">
      <div class="row">
        <div class="col-md-12">
          <i class="text-danger fs-34 d-inline-block ti-trash mb-4"></i>
          <h6>Are you sure you want to delete this email? </h6>
        </div>
      </div>
      <hr />
      <div class="row m-t-15">
        <div class="col-sm-12">
          <button type="button" class="btn btn-sm btn-success mr-1" data-target="#delete-sccess-modal" data-toggle="modal" data-dismiss="modal">delete</button>
          <button type="button" class="btn btn-sm btn-danger ml-1" data-dismiss="modal">Cancel</button>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- success modal -->
<div id="delete-sccess-modal" class="modal fade">
  <div class="modal-dialog modal-sm" data-dismiss="modal">
    <div class="modal-body text-center">
      <div class="row">
        <div class="col-md-12">
          <i class="text-success fs-34 d-inline-block icofont icofont-check-circled mb-4"></i>
          <h6>Successfully Deleted</h6>
        </div>
      </div>
    </div>
  </div>
</div>