<?php include 'header.php' ?>
<div id="accountPage"></div>
<div class="pcoded-content">
  <div class="pcoded-inner-content">
    <div class="main-body">
      <div class="page-wrapper">
        <div class="page-header card">
          <div class="row align-items-end">
            <div class="col-sm-6 col-lg-6">
              <div class="page-header-title d-flex">
                <i class="ti-user bg-c-green"></i>
                <div class="d-inline">
                  <h4>Sub-Admin Management</h4>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-lg-6">
              <div class="page-header-breadcrumb">
                <div class="page-header-breadcrumb">
                  <ul class="breadcrumb-title">
                    <li class="breadcrumb-item">
                      <a href="dashboard.php">
                        <i class="icofont icofont-home"></i>
                      </a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Sub-Admin Management</a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="page-body">
          <div class="card">
            <div class="card-block">
              <div class="dt-plugin-buttons"></div>
              <!-- <div class="mb-4 m-b-15 topForm">
                <label class="d-flex text-dark pull-left mr-3">
                  From <input type="text" class="form-control ml-2 mr-2 wpx85" autocomplete="off" id="start_date"><i class="fa fa-calendar mt-1"></i>
                </label>
                <label class="d-flex text-dark pull-left ml-2 mr-3">
                  To <input type="text" class="form-control ml-2 mr-2 wpx85" autocomplete="off" id="end_date"><i class="fa fa-calendar mt-1"></i>
                </label>
              </div> -->
              <div class="form-group">
                <button class="btn btn-md btn-info" type="button" data-target="#add-modal" data-toggle="modal"><i class="fa fa-user-plus"></i> Add New Sub-Admin</button>
              </div>
              <div class="dt-responsive table-responsive">
                <table id="account-list" class="table table-striped table-bordered nowrap m-0">
                  <thead>
                    <tr>
                      <th>S.No</th>
                      <th>User's Name</th>
                      <th>Email ID</th>
                      <th class="wpx-140">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>01</td>
                      <td>Anshu</td>
                      <td>anshu@gmail.com</td>
                      <td>
                        <button data-toggle="modal" data-target="#edit-modal" class="btn btn-sm btn-info"><i class="ti-pencil"></i></button>
                        <button data-toggle="modal" data-target="#block-modal" class="btn btn-sm btn-warning"><i class="ti-na"></i></button>
                        <!-- <button data-toggle="modal" data-target="#unblock-modal" class="btn btn-sm btn-success"><i class="ti-na"></i></button>-->
                        <button data-toggle="modal" data-target="#delete-modal" class="btn btn-sm btn-danger"><i class="ti-trash"></i></button> 
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div> 
<?php include'footer.php' ?>
<script type="text/javascript">
  $('#account-list').DataTable();
</script>
<!-- block modal -->
<div id="block-modal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-sm">
    <div class="modal-body text-center">
      <div class="row">
        <div class="col-md-12">
          <i class="text-warning fs-34 d-inline-block ti-link mb-4"></i>
          <h6>Are you sure you want to block this sub-admin?</h6>
        </div>
      </div>
      <hr />
      <div class="row m-t-15">
        <div class="col-sm-12">
          <button type="button" class="btn btn-sm btn-success mr-1" data-target="#block-sccess-modal" data-toggle="modal" data-dismiss="modal">Block</button>
          <button type="button" class="btn btn-sm btn-danger ml-1" data-dismiss="modal">Cancel</button>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- unblock modal -->
<div id="unblock-modal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-sm">
    <div class="modal-body text-center">
      <div class="row">
        <div class="col-md-12">
          <i class="text-success fs-34 d-inline-block ti-unlink mb-4"></i>
          <h6>Are you sure you want to unblock this sub-admin? </h6>
        </div>
      </div>
      <hr />
      <div class="row m-t-15">
        <div class="col-sm-12">
          <button type="button" class="btn btn-sm btn-success mr-1" data-target="#unblock-sccess-modal" data-toggle="modal" data-dismiss="modal">Unblock</button>
          <button type="button" class="btn btn-sm btn-danger ml-1" data-dismiss="modal">Cancel</button>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- delete block -->
<div id="delete-modal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-sm">
    <div class="modal-body text-center">
      <div class="row">
        <div class="col-md-12">
          <i class="text-danger fs-34 d-inline-block ti-trash mb-4"></i>
          <h6>Are you sure you want to delete this sub-admin?</h6>
        </div>
      </div>
      <hr />
      <div class="row m-t-15">
        <div class="col-sm-12">
          <button type="button" class="btn btn-sm btn-success mr-1" data-target="#delete-sccess-modal" data-toggle="modal" data-dismiss="modal">Delete</button>
          <button type="button" class="btn btn-sm btn-danger ml-1" data-dismiss="modal">Cancel</button>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- success modal -->
<div id="block-sccess-modal" class="modal fade">
  <div class="modal-dialog modal-sm" data-dismiss="modal">
    <div class="modal-body text-center">
      <div class="row">
        <div class="col-md-12">
          <i class="text-warning fs-34 d-inline-block icofont icofont-check-circled mb-4"></i>
          <h6>Block Successfully</h6>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- success modal -->
<div id="unblock-sccess-modal" class="modal fade">
  <div class="modal-dialog modal-sm" data-dismiss="modal">
    <div class="modal-body text-center">
      <div class="row">
        <div class="col-md-12">
          <i class="text-success fs-34 d-inline-block icofont icofont-check-circled mb-4"></i>
          <h6>Unblock Successfully</h6>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- success modal -->
<div id="delete-sccess-modal" class="modal fade">
  <div class="modal-dialog modal-sm" data-dismiss="modal">
    <div class="modal-body text-center">
      <div class="row">
        <div class="col-md-12">
          <i class="text-danger fs-34 d-inline-block icofont icofont-check-circled mb-4"></i>
          <h6>Delete Successfully</h6>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Add Modal -->
<div id="add-modal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-body">
        <div class="row">
          <div class="col-md-12 form-group">
            <h5>Ada New Sub-Admin</h5>
          </div>
          <div class="col-md-6 form-group">
            <label>Sub-admin Name</label>
            <input type="text" name="name" placeholder="Anshu" class="form-control"/>
          </div> 
          <div class="col-md-6 form-group">
            <label>Email ID</label>
            <input type="email" name="email" placeholder="anshu@gmail.com" class="form-control"/>
          </div>
          <div class="col-md-12">
            <h6>Module rights to be given.</h6>
            <div class="row">
              <div class="col-md-6">
                <div class="checkbox-fade fade-in-primary">
                  <label>
                    <input type="checkbox">
                    <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                    <span class="text-inverse">Dashboard</span>
                  </label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="checkbox-fade fade-in-primary">
                  <label>
                    <input type="checkbox">
                    <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                    <span class="text-inverse">Sub-Admin Management</span>
                  </label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="checkbox-fade fade-in-primary">
                  <label>
                    <input type="checkbox">
                    <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                    <span class="text-inverse">Account Management</span>
                  </label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="checkbox-fade fade-in-primary">
                  <label>
                    <input type="checkbox">
                    <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                    <span class="text-inverse">Subscription Plan Management</span>
                  </label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="checkbox-fade fade-in-primary">
                  <label>
                    <input type="checkbox">
                    <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                    <span class="text-inverse">Payment Management</span>
                  </label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="checkbox-fade fade-in-primary">
                  <label>
                    <input type="checkbox">
                    <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                    <span class="text-inverse">Report Generation</span>
                  </label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="checkbox-fade fade-in-primary">
                  <label>
                    <input type="checkbox">
                    <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                    <span class="text-inverse">Podcast Management</span>
                  </label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="checkbox-fade fade-in-primary">
                  <label>
                    <input type="checkbox">
                    <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                    <span class="text-inverse">Podcast Category Management</span>
                  </label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="checkbox-fade fade-in-primary">
                  <label>
                    <input type="checkbox">
                    <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                    <span class="text-inverse">Notifiaction Management</span>
                  </label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="checkbox-fade fade-in-primary">
                  <label>
                    <input type="checkbox">
                    <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                    <span class="text-inverse">Setting Management</span>
                  </label>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-12 text-center">
            <button class="btn btn-md btn-success" data-dismiss="modal" data-target="#save-success-modal" data-toggle="modal">Save</button>
            <button class="btn btn-md btn-danger" data-dismiss="modal">Cancel</button>
          </div>
        </div>
      </div>
    </div>  
  </div>
</div> 
<!-- Edit modal -->
<div id="edit-modal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-body">
        <div class="row">
          <div class="col-md-12 form-group">
            <h5>Edit Sub-Admin</h5>
          </div>
          <div class="col-md-6 form-group">
            <label>Sub-admin Name</label>
            <input type="text" name="name" value="Anshu" class="form-control"/>
          </div> 
          <div class="col-md-6 form-group">
            <label>Email ID</label>
            <input type="email" name="email" value="anshu@gmail.com" class="form-control"/>
          </div>
          <div class="col-md-12">
            <h6>Module rights to be given.</h6>
            <div class="row">
              <div class="col-md-6">
                <div class="checkbox-fade fade-in-primary">
                  <label>
                    <input type="checkbox">
                    <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                    <span class="text-inverse">Dashboard</span>
                  </label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="checkbox-fade fade-in-primary">
                  <label>
                    <input type="checkbox">
                    <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                    <span class="text-inverse">Sub-Admin Management</span>
                  </label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="checkbox-fade fade-in-primary">
                  <label>
                    <input type="checkbox">
                    <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                    <span class="text-inverse">Account Management</span>
                  </label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="checkbox-fade fade-in-primary">
                  <label>
                    <input type="checkbox">
                    <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                    <span class="text-inverse">Subscription Plan Management</span>
                  </label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="checkbox-fade fade-in-primary">
                  <label>
                    <input type="checkbox">
                    <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                    <span class="text-inverse">Payment Management</span>
                  </label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="checkbox-fade fade-in-primary">
                  <label>
                    <input type="checkbox">
                    <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                    <span class="text-inverse">Report Generation</span>
                  </label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="checkbox-fade fade-in-primary">
                  <label>
                    <input type="checkbox">
                    <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                    <span class="text-inverse">Podcast Management</span>
                  </label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="checkbox-fade fade-in-primary">
                  <label>
                    <input type="checkbox">
                    <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                    <span class="text-inverse">Podcast Category Management</span>
                  </label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="checkbox-fade fade-in-primary">
                  <label>
                    <input type="checkbox">
                    <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                    <span class="text-inverse">Notifiaction Management</span>
                  </label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="checkbox-fade fade-in-primary">
                  <label>
                    <input type="checkbox">
                    <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                    <span class="text-inverse">Setting Management</span>
                  </label>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-12 text-center">
            <button class="btn btn-md btn-success" data-dismiss="modal" data-target="#save-success-modal" data-toggle="modal">Save</button>
            <button class="btn btn-md btn-danger" data-dismiss="modal">Cancel</button>
          </div>
        </div>
      </div>
    </div>  
  </div>
</div>  
<!-- success modal -->
<div id="save-success-modal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-sm" data-dismiss="modal">    
    <div class="modal-body text-center">
      <div class="row">
        <div class="col-md-12">
          <i class="text-success fs-34 d-inline-block icofont icofont-check-circled mb-4"></i>
          <h6>Saved Successfully</h6>
        </div>
      </div>
    </div>
  </div>
</div>