<?php include 'header.php' ?>
<div id="dashboardPage"></div>
<div class="pcoded-content">
  <div class="pcoded-inner-content">
    <div class="main-body">
      <div class="page-wrapper">
        <div class="page-header card">
          <div class="row align-items-end">
            <div class="col-sm-6 col-lg-6">
              <div class="page-header-title d-flex">
                <i class="ti-user bg-c-green"></i>
                <div class="d-inline">
                  <h4>Report Management</h4>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-lg-6">
              <div class="page-header-breadcrumb">
                <div class="page-header-breadcrumb">
                  <ul class="breadcrumb-title">
                    <li class="breadcrumb-item">
                      <a href="dashboard.php">
                        <i class="icofont icofont-home"></i>
                      </a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Report Management</a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="page-body">
          <div class="row">
            <div class="col-8 col-sm-5 col-md-4 col-lg-3 mb-3">
              <select class="form-control">
                <option value="Weekly">Weekly</option>
                <option value="Monthly">Monthly</option>
                <option value="Yearly">Yearly</option>
              </select>
            </div>
            <div class="col-4 col-sm-7 col-md-8 col-lg-9 text-right mb-3">
              <button type="button" class="btn btn-md d-inline-block btn-info">Export</button>
            </div>
          </div> 
          <div class="row height-box">
            <div class="col-12 col-sm-6 col-md-3 col-lg-3 full-height">
              <div class="card bg-c-broun text-white widget-visitor-card">
                <div class="card-block-small text-center">
                  <h2>1,658</h2>
                  <h6>Total Number of Users</h6>
                  <i class="ti-user courner"></i>
                </div>
              </div>
            </div>
            <div class="col-12 col-sm-6 col-md-3 col-lg-3 full-height">
              <div class="card bg-c-yellow text-white widget-visitor-card">
                <div class="card-block-small text-center">
                  <h2>1,658</h2>
                  <h6>Total Number of Podcasters</h6>
                  <i class="ti-announcement courner"></i>
                </div>
              </div>
            </div>
            <div class="col-12 col-sm-6 col-md-3 col-lg-3 full-height">
              <div class="card bg-c-pink text-white widget-visitor-card">
                <div class="card-block-small text-center">
                  <h3>1,658</h3>
                  <h6>Total Number of App Downloads</h6>
                  <i class="fa fa-download courner"></i>
                </div>
              </div>
            </div>
            <div class="col-12 col-sm-6 col-md-3 col-lg-3 full-height">
              <div class="card bg-c-blue text-white widget-visitor-card">
                <div class="card-block-small text-center">
                  <h3>1,658</h3>
                  <h6>Total Number of Hosted Podcasts</h6>
                  <i class="ti-microphone courner"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include'footer.php' ?>
