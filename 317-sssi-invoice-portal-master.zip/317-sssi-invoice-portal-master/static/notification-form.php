<?php include 'header.php' ?>
<div id="profilePage"></div>
<div class="pcoded-content">
  <div class="pcoded-inner-content">
    <div class="main-body user-profile">
      <div class="page-wrapper">
        <div class="page-header card">
          <div class="row align-items-end">
            <div class="col-sm-6 col-lg-6">
              <div class="page-header-title d-flex">
                <i class="ti-bell bg-danger"></i>
                <div class="d-inline">
                  <h4>Notification</h4>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-lg-6">
              <div class="page-header-breadcrumb">
                <ul class="breadcrumb-title">
                  <li class="breadcrumb-item">
                    <a href="dashboard.php">
                      <i class="icofont icofont-home"></i>
                    </a>
                  </li>
                  <li class="breadcrumb-item"><a href="notification.php">Notification</a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="page-body">
          <div class="card p-3">                    
            <form action="#" method="post">
              <div class="form-group">
                <label>Notification Title</label>
                <input type="text" class="form-control">
              </div>
              <div class="form-group">
                <label>Notification Description</label>
                <textarea rows="5" class="form-control"></textarea>
              </div>
              <div class="text-center">
                <a href="user-list.php" class="btn btn-info"><i class="fa fa-users mr-1"></i> Add User</a>
                <button type="button" class="btn btn-primary" data-target="#sccess-modal" data-toggle="modal">Send Notification</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- success modal -->
       
<?php include'footer.php' ?>


<!-- success modal -->
<div id="sccess-modal" class="modal fade">
  <div class="modal-dialog modal-sm" data-dismiss="modal">
    <div class="modal-body text-center">
      <div class="row">
        <div class="col-md-12">
          <i class="text-warning fs-34 d-inline-block icofont icofont-check-circled mb-4"></i>
          <h6>Notification Sent Successfully</h6>
        </div>
      </div>
    </div>
  </div>
</div>