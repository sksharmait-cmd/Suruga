<?php include 'header.php' ?>
<div id="accountPage"></div>
<div class="pcoded-content">
  <div class="pcoded-inner-content">
    <div class="main-body">
      <div class="page-wrapper">
        <div class="page-header card">
          <div class="row align-items-end">
            <div class="col-sm-6 col-lg-6">
              <div class="page-header-title d-flex">
                <i class="ti-user bg-c-green"></i>
                <div class="d-inline">
                  <h4>User List</h4>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-lg-6">
              <div class="page-header-breadcrumb">
                <div class="page-header-breadcrumb">
                  <ul class="breadcrumb-title">
                    <li class="breadcrumb-item">
                      <a href="dashboard.php">
                        <i class="icofont icofont-home"></i>
                      </a>
                    </li>
                    <li class="breadcrumb-item"><a href="notification-form.php">Notification</a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="page-body">
          <div class="card">
            <div class="card-block">
              <div class="dt-plugin-buttons"></div>
              <div class="dt-responsive table-responsive">
                <table id="user-list" class="table table-striped table-bordered nowrap m-0">
                  <thead>
                    <tr>
                      <th class="no-sort" width="66">
                        <div class="checkbox-fade">
                          <label>
                            <input type="checkbox" id="selectAll">
                            <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                          </label>
                        </div>
                      </th>
                      <th>User's Name</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <div class="checkbox-fade">
                          <label>
                            <input type="checkbox">
                            <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                          </label>
                        </div>
                      </td>
                      <td><img src="assets/images/avatar-4.jpg" width="30px;" class="img-radius mr-2" alt="User-Profile-Image">Anshu</td>
                    </tr>
                    <tr>
                      <td>
                        <div class="checkbox-fade">
                          <label>
                            <input type="checkbox">
                            <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                          </label>
                        </div>
                      </td>
                      <td><img src="assets/images/avatar-4.jpg" width="30px;" class="img-radius mr-2" alt="User-Profile-Image">Anshu</td>
                    </tr>
                    <tr>
                      <td>
                        <div class="checkbox-fade">
                          <label>
                            <input type="checkbox">
                            <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                          </label>
                        </div>
                      </td>
                      <td><img src="assets/images/avatar-4.jpg" width="30px;" class="img-radius mr-2" alt="User-Profile-Image">Anshu</td>
                    </tr>
                    <tr>
                      <td>
                        <div class="checkbox-fade">
                          <label>
                            <input type="checkbox">
                            <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                          </label>
                        </div>
                      </td>
                      <td><img src="assets/images/avatar-4.jpg" width="30px;" class="img-radius mr-2" alt="User-Profile-Image">Anshu</td>
                    </tr>
                    <tr>
                      <td>
                        <div class="checkbox-fade">
                          <label>
                            <input type="checkbox">
                            <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                          </label>
                        </div>
                      </td>
                      <td><img src="assets/images/avatar-4.jpg" width="30px;" class="img-radius mr-2" alt="User-Profile-Image">Anshu</td>
                    </tr>
                    <tr>
                      <td>
                        <div class="checkbox-fade">
                          <label>
                            <input type="checkbox">
                            <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                          </label>
                        </div>
                      </td>
                      <td><img src="assets/images/avatar-4.jpg" width="30px;" class="img-radius mr-2" alt="User-Profile-Image">Anshu</td>
                    </tr>
                    <tr>
                      <td>
                        <div class="checkbox-fade">
                          <label>
                            <input type="checkbox">
                            <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                          </label>
                        </div>
                      </td>
                      <td><img src="assets/images/avatar-4.jpg" width="30px;" class="img-radius mr-2" alt="User-Profile-Image">Anshu</td>
                    </tr>
                    <tr>
                      <td>
                        <div class="checkbox-fade">
                          <label>
                            <input type="checkbox">
                            <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                          </label>
                        </div>
                      </td>
                      <td><img src="assets/images/avatar-4.jpg" width="30px;" class="img-radius mr-2" alt="User-Profile-Image">Anshu</td>
                    </tr><tr>
                      <td>
                        <div class="checkbox-fade">
                          <label>
                            <input type="checkbox">
                            <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                          </label>
                        </div>
                      </td>
                      <td><img src="assets/images/avatar-4.jpg" width="30px;" class="img-radius mr-2" alt="User-Profile-Image">Anshu</td>
                    </tr>
                  </tbody>
                </table>
                <div class="text-center">
                  <button type="button" class="btn btn-primary">Selected</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div> 
<?php include'footer.php' ?>
<script type="text/javascript">
  $('#user-list').DataTable({
    columnDefs: [
      { targets: 'no-sort', orderable: false }
    ]
  });

  $('#selectAll').on('click', function() {
    if($(this).is(':checked')){
      $('#user-list tr td input[type=checkbox]').prop('checked', true)
    }else{
      $('#user-list tr td input[type=checkbox]').prop('checked', false)
    }
  })
</script>

<!-- success modal -->
<div id="sccess-modal" class="modal fade">
  <div class="modal-dialog modal-sm" data-dismiss="modal">
    <div class="modal-body text-center">
      <div class="row">
        <div class="col-md-12">
          <i class="text-warning fs-34 d-inline-block icofont icofont-check-circled mb-4"></i>
          <h6>User added Successfully</h6>
        </div>
      </div>
    </div>
  </div>
</div>