<!DOCTYPE html>
<html lang="en">
<head>
  <title>a2a</title>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="description" content="#" />
  <meta name="keywords" content="" />
  <meta name="author" content="#" />
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <link rel="icon" href="assets/images/favicon.png" type="image/x-icon" />
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,800" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css" />
  <link rel="stylesheet" type="text/css" href="assets/icon/themify-icons/themify-icons.css" />
  <link rel="stylesheet" type="text/css" href="assets/icon/icofont/css/icofont.css" />
  <link rel="stylesheet" type="text/css" href="assets/css/style.css" />
</head>
<body class="fix-menu">
  <section class="login common-img-bg">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="login-card card-block auth-body mr-auto ml-auto">
            <form class="md-float-material">
              <div class="auth-box">
                <div class="text-center">
                  <img src="assets/images/logo-1.png" alt="logo" />
                </div>
                <div class="row m-b-20">
                  <div class="col-md-12">
                    <h3 class="text-left">Forgot Password</h3>
                  </div>
                </div>
                <p class="text-inverse text-right">Back to <a href="login.php"><strong>Login</strong></a></p>
                <div class="input-group input-group-primary">
                  <span class="input-group-addon">
                    <i class="icofont icofont-envelope"></i>
                  </span>
                  <input type="text" class="form-control" placeholder="Your Email Address" />
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <a href="reset-password.php" class="btn btn-primary btn-md btn-block waves-effect text-center m-b-20">Send Link</a>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
</body>
</html>