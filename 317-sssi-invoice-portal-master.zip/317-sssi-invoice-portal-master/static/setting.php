<?php include 'header.php' ?>
<div id="profilePage"></div>
<div class="pcoded-content">
  <div class="pcoded-inner-content">
    <div class="main-body user-profile">
      <div class="page-wrapper">
        <div class="page-header card">
          <div class="row align-items-end">
            <div class="col-sm-6 col-lg-6">
              <div class="page-header-title d-flex">
                <i class="fa fa-cog bg-danger"></i>
                <div class="d-inline">
                  <h4>Setting</h4>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-lg-6">
              <div class="page-header-breadcrumb">
                <ul class="breadcrumb-title">
                  <li class="breadcrumb-item">
                    <a href="dashboard.php">
                      <i class="icofont icofont-home"></i>
                    </a>
                  </li>
                  <li class="breadcrumb-item"><a href="setting.php">Setting</a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="page-body">
          <div class="card p-3">
            <h5>Terms and Conditions <button type="button" class="pull-right btn btn-info btn-sm" data-target="#terms-modal" data-toggle="modal"><i class="fa fa-pencil"></i></h5>
            <p>Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups. Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.</p>
          </div>
          <div class="card p-3">
            <h5>Help <button type="button" class="pull-right btn btn-info btn-sm" data-target="#help-modal" data-toggle="modal"><i class="fa fa-pencil"></i></h5>
            <p>Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups. Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.</p>
          </div>
          <div class="card p-3">
            <h5>FAQ's <button type="button" class="pull-right btn btn-info btn-sm" data-target="#faq-modal" data-toggle="modal"><i class="fa fa-pencil"></i></h5>
            <p>Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups. Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.</p>
          </div>
          <div class="card p-3">
            <h5>Legal <button type="button" class="pull-right btn btn-info btn-sm" data-target="#legal-modal" data-toggle="modal"><i class="fa fa-pencil"></i></h5>
            <p>Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups. Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- success modal -->
       
<?php include'footer.php' ?>

<!-- Terms modal -->
<div class="modal fade" id="terms-modal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
        <h6>Terms And Conditions</h6>
        <form action="#">
          <div class="form-group">
            <textarea class="form-control" rows="5" placeholder="Enter Text"></textarea>
          </div>
          <div class="text-center">
            <button type="button" class="btn btn-sm btn-success" data-dismiss="modal">SAVE</button>
            <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal">CANCEL</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>  
<!-- Help modal -->
<div class="modal fade" id="help-modal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
        <h6>Help</h6>
        <form action="#">
          <div class="form-group">
            <textarea class="form-control" rows="5" placeholder="Enter Text"></textarea>
          </div>
          <div class="text-center">
            <button type="button" class="btn btn-sm btn-success" data-dismiss="modal">SAVE</button>
            <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal">CANCEL</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>  
<!-- FAQ -->
<div class="modal fade" id="faq-modal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
        <h6>FAQ's</h6>
        <form action="#">
          <div class="form-group">
            <textarea class="form-control" rows="5" placeholder="Enter Text"></textarea>
          </div>
          <div class="text-center">
            <button type="button" class="btn btn-sm btn-success" data-dismiss="modal">SAVE</button>
            <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal">CANCEL</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>  
<!-- Legal modal -->
<div class="modal fade" id="legal-modal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
        <h6>Legal And Conditions</h6>
        <form action="#">
          <div class="form-group">
            <textarea class="form-control" rows="5" placeholder="Enter Text"></textarea>
          </div>
          <div class="text-center">
            <button type="button" class="btn btn-sm btn-success" data-dismiss="modal">SAVE</button>
            <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal">CANCEL</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>  