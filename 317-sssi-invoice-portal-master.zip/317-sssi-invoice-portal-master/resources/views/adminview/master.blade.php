<!DOCTYPE html>

<html lang="en">



<head>

  <!-- Required meta tags -->

  <meta charset="utf-8">

  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>Suruga India</title>

  <link rel="stylesheet" href="{{url('/assets/vendors/mdi/css/materialdesignicons.min.css')}}">

  <!-- inject:css -->

  <link rel="stylesheet" href="{{url('/assets/css/vertical-layout-light/style.css')}}">

  <!-- endinject -->

  <script type="text/javascript" src="{{url('/assets/js/jquery.min.js')}}"></script>

</head>

<body>

  <div class="container-scroller"> 

    <!-- partial:partials/_navbar.html -->

    <nav class="navbar default-layout col-lg-12 col-12 p-0 fixed-top d-flex align-items-top flex-row">

      <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-start">

        <div class="me-3">

          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-bs-toggle="minimize">

            <span class="icon-menu"></span>

          </button>

        </div>

        <div>

          <a class="navbar-brand brand-logo text-light" href="{{route('dashboard')}}">

            Admin

          </a>

          <a class="navbar-brand brand-logo-mini" href="{{route('dashboard')}}">

            Admin

          </a>

        </div>

      </div>

      <div class="navbar-menu-wrapper d-flex align-items-top"> 

      

        <ul class="navbar-nav ms-auto">

          <li class="nav-item dropdown d-none d-lg-block user-dropdown">

            <a class="nav-link" id="UserDropdown" href="#" data-bs-toggle="dropdown" aria-expanded="false">

              <img class="img-xs rounded-circle" src="{{url('/assets/images/faces/profile.png')}}" alt="Profile image"> </a>

            <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">

              <div class="dropdown-header text-center">

                <img class="img-md rounded-circle" src="{{url('/assets/images/faces/profile.png')}}" alt="Profile image">

                <p class="mb-1 mt-3 font-weight-semibold">Admin</p>

              </div>

              <a class="dropdown-item" href="{{route('logout')}}"><i class="dropdown-item-icon mdi mdi-power text-primary me-2"></i>Sign Out</a>

            </div>

          </li>

        </ul>

        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-bs-toggle="offcanvas">

          <span class="mdi mdi-menu"></span>

        </button>

      </div>

    </nav>

    <!-- partial -->

    <div class="container-fluid page-body-wrapper ">

      <!-- partial -->

      <!-- partial:partials/_sidebar.html -->

      <nav class="sidebar sidebar-offcanvas" id="sidebar">

        <ul class="nav">

          <li class="nav-item {{(last(request()->segments())=='dashboard')?'active':''}}">

            <a class="nav-link" href="{{route('dashboard')}}">

              <i class="mdi mdi-grid-large menu-icon"></i>

              <span class="menu-title">Dashboard</span>

            </a>

          </li>

          <li class="nav-item {{(last(request()->segments())=='manage-import')?'active':''}}">

            <a class="nav-link" href="{{route('importer')}}">

              <i class="menu-icon mdi mdi-file-import"></i>

              <span class="menu-title">Row Import Data</span>

            </a>

          </li>

          <li class="nav-item {{(last(request()->segments())=='manage-export')?'active':''}}">

            <a class="nav-link" href="{{route('exporter')}}">

              <i class="menu-icon mdi mdi-file-export"></i>

              <span class="menu-title">Template Export Data</span>

            </a>

          </li>

          <li class="nav-item">

            <a class="nav-link" href="{{route('logout')}}">

              <i class="menu-icon mdi mdi-power"></i>

              <span class="menu-title">Sign Out</span>

            </a>

          </li>

        </ul>

      </nav>

<!-- BODY -->



@yield('bodyarea')



<!-- FOOTER -->



<!-- partial:partials/_footer.html -->

<footer class="footer">

          <div class="d-sm-flex justify-content-center justify-content-sm-between">

            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Copyright © 2021. All rights reserved.</span>

          </div>

        </footer>

        <!-- partial -->

      </div>

      <!-- main-panel ends -->

    </div>

    <!-- page-body-wrapper ends -->

  </div>



  <!-- End plugin js for this page -->

  <!-- inject:js -->



</body>



</html>



