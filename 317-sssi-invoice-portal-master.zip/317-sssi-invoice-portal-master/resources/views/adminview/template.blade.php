<table>
    <thead>
        <tr>
            <th>Seller GSTIN *</th>
            <th>Seller legal Name</th>
            <th>Seller Trade Name</th>
            <th>Seller Addr1</th>
            <th>Seller Addr2</th>
            <th>Seller Location</th>
            <th>Seller Pin code</th>
            <th>Seller state</th>
            <th>Seller Phone number</th>
            <th>Seller email ID</th>
            <th>Supply type code *</th>
            <th>Reverse Charge</th>
            <th>E-comm GSTIN</th>
            <th>IGST on Intra</th>
            <th>Document type *</th>
            <th>Document Number *</th>
            <th>Document Date (DD/MM/YYYY) *</th>
            <th>Buyer GSTIN *</th>
            <th>Buyer legal Name *</th>
            <th>Buyer Trade Name</th>
            <th>Buyer POS *</th>
            <th>Buyer Addr1 *</th>
            <th>Buyer Addr2</th>
            <th>Buyer Location *</th>
            <th>Buyer Pin code</th>
            <th>Buyer state*</th>
            <th>Buyer Phone number</th>
            <th>Buyer email ID</th>
            <th>Dispatch Name</th>
            <th>Dispatch Addr1</th>
            <th>Dispatch Addr2</th>
            <th>Dispatch Location</th>
            <th>Dispatch Pin code</th>
            <th>Dispatch state</th>
            <th>Shipping GSTIN</th>
            <th>Shipping legal Name</th>
            <th>Shipping Trade Name</th>
            <th>Shipping Addr1</th>
            <th>Shipping Addr2</th>
            <th>Shipping Location</th>
            <th>Shipping Pin code</th>
            <th>Shipping state</th>
            <th>SI.NO. *</th>
            <th>Product Description</th>
            <th>Is_Service *</th>
            <th>HSN Code *</th>
            <th>Bar code</th>
            <th>Quantity *</th>
            <th>Free Quantity</th>
            <th>UNIT *</th>
            <th>Unit Price *</th>
            <th>Gross Amount *</th>
            <th>Discount</th>
            <th>Pre tax value</th>
            <th>Taxable value *</th>
            <th>GST Rate (%) *</th>
            <th>Sgst Amt (Rs)</th>
            <th>Cgst Amt (Rs)</th>
            <th>Igst Amt (Rs)</th>
            <th>Cess Rate (%)</th>
            <th>Cess Amt Adval (Rs)</th>
            <th>Cess Non-Adval Amt (Rs)</th>
            <th>State Cess Rate (%)</th>
            <th>State Cess Amt Adval (Rs)</th>
            <th>State Cess Non-Adval Amt (Rs)</th>
            <th>Other Charges</th>
            <th>Item Total *</th>
            <th>Order Line reference</th>
            <th>Orgin country</th>
            <th>Unique Item SI. No.</th>
            <th>Batch Name</th>
            <th>Batch Expiry Dt</th>
            <th>Warranty Dt</th>
            <th>Attribute Details of the items</th>
            <th>Attribute Value of the item</th>
            <th>Total Taxable value *</th>
            <th>SGST Amt</th>
            <th>CGST Amt</th>
            <th>IGST Amt</th>
            <th>Cess Amt</th>
            <th>State Cess Amt</th>
            <th>Discount</th>
            <th>Other Charges</th>
            <th>Round Off</th>
            <th>Total Invoice value *</th>
            <th>Total Invoice value in Additional Curr</th>
            <th>Shipping Bill No.</th>
            <th>Shipping Bill Dt</th>
            <th>Port</th>
            <th>Supplier Refund</th>
            <th>Foreign Currency</th>
            <th>Country Code</th>
            <th>Export Duty Amount</th>
            <th>Trans ID</th>
            <th>Trans Name</th>
            <th>Trans Mode</th>
            <th>Distance</th>
            <th>Trans Doc No.</th>
            <th>Trans Doc Date</th>
            <th>Vehicle No.</th>
            <th>Vehicle Type</th>
            <th>Payee Name</th>
            <th>Account Number</th>
            <th>Mode</th>
            <th>Branch/IFSC code</th>
            <th>Term of Payment</th>
            <th>Payment Instruction</th>
            <th>Credit Transfer</th>
            <th>Direct Debit</th>
            <th>Credit Days</th>
            <th>Paided amount</th>
            <th>Due amount</th>
            <th>Remarks</th>
            <th>Invoice Period Start Date</th>
            <th>Invoice Period End Date</th>
            <th>Original Invoice</th>
            <th>Preceding Invoice Date</th>
            <th>Other Reference</th>
            <th>Receipt Advice No.</th>
            <th>Date of Receipt Advice</th>
            <th>Lot/Batch Reference No.</th>
            <th>Contract Reference Number</th>
            <th>Any other reference</th>
            <th>Project Reference Number</th>
            <th>Vendor PO Reference Number</th>
            <th>Vendor's PO Reference Date</th>
            <th>Supporting document URL</th>
            <th>Supporting document in Base64 Format</th>
            <th>Any additional information</th>
            <th>Custom</th>
            <th>Custom2</th>
            <th>Custom3</th>
            <th>Custom4</th>
            <th>Custom5</th>
            <th>Custom6</th>
            <th>Custom7</th>
            <th>Custom8</th>
            <th>Custom9</th>
            <th>Custom10</th>
        </tr>
    </thead>
    <tbody>
        @php
            $total = 0;
            $incTaxpaybleAmount = 0;
            $sn = 0;
        @endphp
        @foreach ($exceldata as $getexcel)
            @php
                $sn++;
                $uprice = $getexcel['rsc_col_14'];
                $igst = ($uprice * 18) / 100;
                $gross = $uprice + $igst;
                $total = $total + $gross;
                $paybleAmount = array_sum(array_column($exceldata, 'rsc_col_14'));
                $incTaxpaybleAmount = $paybleAmount + ($paybleAmount * 18) / 100;
            @endphp
            <tr>
                <td>{{ $getexcel['surg_gst'] }}</td>
                <td>{{ $getexcel['surg_legal_name'] }}</td>
                <td>{{ $getexcel['surg_trade_ame'] }}</td>
                <td>{{ $getexcel['surg_addr1'] }}</td>
                <td>{{ $getexcel['surg_addr2'] }}</td>
                <td>{{ $getexcel['surg_location'] }}</td>
                <td>{{ $getexcel['surg_pincode'] }}</td>
                <td>{{ $getexcel['surg_state'] }}</td>
                <td>{{ substr(preg_replace('/[^0-9]/', '', $getexcel['surg_phone_number']), -12) }}</td>
                <td>{{ $getexcel['surg_email'] }}</td>
                <td>B2B</td>
                <td>N</td>
                <td></td>
                <td></td>
                <td>INV</td>
                <td>{{ $getexcel['rsc_col_1'] }}</td>
                <td>{{ date('d/m/Y') }}</td>
                <td>{{ BUYER[$getexcel['rsc_col_3']]['gst'] }}</td>
                <td>{{ BUYER[$getexcel['rsc_col_3']]['lname'] }}</td>
                <td>{{ BUYER[$getexcel['rsc_col_3']]['tname'] }}</td>
                <td>{{ round(substr(BUYER[$getexcel['rsc_col_3']]['gst'], 0, 2)) }}</td>
                <td>{{ BUYER[$getexcel['rsc_col_3']]['addr1'] }}</td>
                <td>{{ BUYER[$getexcel['rsc_col_3']]['addr2'] }}</td>
                <td>{{ BUYER[$getexcel['rsc_col_3']]['loc'] }}</td>
                <td>{{ BUYER[$getexcel['rsc_col_3']]['pin'] }}</td>
                <td>{{ BUYER[$getexcel['rsc_col_3']]['state'] }}</td>
                <td>{{ BUYER[$getexcel['rsc_col_3']]['phone'] }}</td>
                <td>{{ BUYER[$getexcel['rsc_col_3']]['email'] }}</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td>{{ BUYER[$getexcel['rsc_col_3']]['gst'] }}</td>
                <td>{{ BUYER[$getexcel['rsc_col_3']]['lname'] }}</td>
                <td>{{ BUYER[$getexcel['rsc_col_3']]['tname'] }}</td>
                <td>{{ BUYER[$getexcel['rsc_col_3']]['addr1'] }}</td>
                <td>{{ BUYER[$getexcel['rsc_col_3']]['addr2'] }}</td>
                <td>{{ BUYER[$getexcel['rsc_col_3']]['loc'] }}</td>
                <td>{{ BUYER[$getexcel['rsc_col_3']]['pin'] }}</td>
                <td>{{ BUYER[$getexcel['rsc_col_3']]['state'] }}</td>
                <td>{{ $sn }}</td>
                <td>{{ $getexcel['rsc_col_6'] }}</td>
                <td>N</td>
                <td>{{ $getexcel['rsc_col_19'] }}</td>
                <td>{{ $getexcel['rsc_col_7'] }}</td>
                <td>{{ $getexcel['rsc_col_10'] }}</td>
                <td></td>
                <td>NOS</td>
                <td>{{round($getexcel['rsc_col_12'],2)}}</td>
                <td>{{ round($uprice, 2) }}</td>
                <td></td>
                <td></td>
                <td>{{ round($uprice, 2) }}</td>
                <td>18</td>
                <td>{{ $getexcel['rsc_col_3'] == 'H' ? round($igst / 2, 2) : '' }}</td>
                <td>{{ $getexcel['rsc_col_3'] == 'H' ? round($igst / 2, 2) : '' }}</td>
                <td>{{ $getexcel['rsc_col_3'] == 'K' || $getexcel['rsc_col_3'] == 'M' ? round($igst, 2) : '' }}</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td>{{ round($gross, 2) }}</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td>{{ round($paybleAmount, 2) }}</td>
                <td>{{ $getexcel['rsc_col_3'] == 'H' ? round(($paybleAmount * 9) / 100, 2) : '' }}</td>
                <td>{{ $getexcel['rsc_col_3'] == 'H' ? round(($paybleAmount * 9) / 100, 2) : '' }}</td>
                <td>{{ $getexcel['rsc_col_3'] == 'K' || $getexcel['rsc_col_3'] == 'M' ? round(($paybleAmount * 18) / 100, 2) : '' }}</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td>{{ round($incTaxpaybleAmount, 2) }}</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
        @endforeach
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
    </tbody>
</table>
