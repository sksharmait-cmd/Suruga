<table>

    <thead>

    <tr>

<th>INVOICE_NO</th>

<th>DETAIL_SEQ</th>

<th>SERIAL_NO</th>

<th>CUST_BOX</th>

<th>INVOICE_DATE</th>

<th>MODE_OF_TRANSPORT</th>

<th>PAYMENT_TERMS</th>

<th>IMPORT_INVOICE</th>

<th>BILL_CD</th>

<th>BILL_NAME</th>

<th>BILL_ADDRESS1</th>

<th>BILL_ADDRESS2</th>

<th>BILL_ADDRESS3</th>

<th>BILL_ADDRESS4</th>

<th>BILL_TEL</th>

<th>BILL_GSTIN_NO</th>

<th>SHIP_CD</th>

<th>SHIP_NAME</th>

<th>SHIP_ADDRESS1</th>

<th>SHIP_ADDRESS2</th>

<th>SHIP_ADDRESS3</th>

<th>SHIP_ADDRESS4</th>

<th>SHIP_TEL</th>

<th>SHIP_GSTIN_NO</th>

<th>ITEM_NO</th>

<th>DESCRIPTION</th>

<th>SAMPLE_FLG</th>

<th>CST_SUB_REF</th>

<th>HSN</th>

<th>STOCK_TYPE</th>

<th>QUANTITY</th>

<th>UNIT</th>

<th>RATE_UNIT</th>

<th>TOTAL_TAXABLE_AMOUNT</th>

<th>CGST_RATE</th>

<th>CGST_AMOUNT</th>

<th>CGST_AMOUNT_SUM</th>

<th>SGST_RATE</th>

<th>SGST_AMOUNT</th>

<th>SGST_AMOUNT_SUM</th>

<th>IGST_RATE</th>

<th>IGST_AMOUNT</th>

<th>IGST_AMOUNT_SUM</th>

<th>QUANTITY_SUM</th>

<th>TOTAL_TAXABLE_AMOUNT_SUM</th>

<th>TOTAL_AMOUNT_AFTER_DISCOUNT</th>

<th>FREIGHT</th>

<th>FREIGHT_DISCOUNT</th>

<th>MISC</th>

<th>INSURANCE</th>

<th>GRAND_TOTAL</th>

<th>GRAND_TOTAL_EN</th>

<th>FREIGHT_RATE_CGST</th>

<th>FREIGHT_CGST</th>

<th>FREIGHT_RATE_SGST</th>

<th>FREIGHT_SGST</th>

<th>FREIGHT_RATE_IGST</th>

<th>FREIGHT_IGST</th>

<th>INSURANCE_RATE_CGST</th>

<th>INSURANCE_CGST</th>

<th>INSURANCE_RATE_SGST</th>

<th>INSURANCE_SGST</th>

<th>INSURANCE_RATE_IGST</th>

<th>INSURANCE_IGST</th>

<th>DELETE_FLG</th>

<th>REGIST_DATE</th>

<th>REGIST_USER_ID</th>

<th>UPDATE_DATE</th>

<th>UPDATE_USER_ID</th>

<th>UPDATE_CNT</th>

<th>UPD_PWC</th>

<th>UPD_BAT_TIME</th>

<th>SESSION_START_TIME</th>

    </tr>

    </thead>

    <tbody>

    @foreach($exceldata as $getexcel)

        <tr>

        @for($i=1; $i<=73; $i++)

            <td>{{ $getexcel->{'rsc_col_'.$i} }}</td>

        @endfor

        </tr>

    @endforeach

    </tbody>

</table>