<?php

$tempArray = [
    'col_1' => 'surg_gst',
    'col_2' => 'surg_legal_name',
    'col_3' => 'surg_trade_ame',
    'col_4' => 'surg_addr1',
    'col_5' => 'surg_addr2',
    'col_6' => 'surg_location',
    'col_7' => 'surg_pincode',
    'col_8' => 'surg_state',
    'col_9' => 'surg_phone_number',
    'col_10' => 'surg_email',
    'col_11' => '',
    'col_12' => '',
    'col_13' => '',
    'col_14' => '',
    'col_15' => '',
    'col_16' => 'rsc_col_1',
    'col_17' => 'rsc_col_5',
    'col_18' => 'rsc_col_16',
    'col_19' => 'rsc_col_9',
    'col_20' => '',
    'col_21' => '',
    'col_22' => 'rsc_col_11',
    'col_23' => 'rsc_col_12-rsc_col_13',
    'col_24' => 'rsc_col_14',
    'col_25' => '',
    'col_26' => '',
    'col_27' => 'rsc_col_15',
    'col_28' => '',
    'col_29' => '',
    'col_30' => '',
    'col_31' => '',
    'col_32' => '',
    'col_33' => '',
    'col_34' => '',
    'col_35' => 'rsc_col_24',
    'col_36' => 'rsc_col_18',
    'col_37' => '',
    'col_38' => 'rsc_col_19',
    'col_39' => 'rsc_col_20-rsc_col_21',
    'col_40' => 'rsc_col_22',
    'col_41' => '',
    'col_42' => '',
    'col_43' => 'rsc_col_2',
    'col_44' => 'rsc_col_26',
    'col_45' => '',
    'col_46' => 'rsc_col_29',
    'col_47' => 'rsc_col_25',
    'col_48' => 'rsc_col_31',
    'col_49' => '',
    'col_50' => 'rsc_col_32',
    'col_51' => 'rsc_col_33',
    'col_52' => 'rsc_col_34',
    'col_53' => '',
    'col_54' => '',
    'col_55' => 'rsc_col_34',
    'col_56' => 'rsc_col_35-rsc_col_38-rsc_col_41',
    'col_57' => 'rsc_col_39',
    'col_58' => 'rsc_col_36',
    'col_59' => 'rsc_col_42',
    'col_60' => '',
    'col_61' => '',
    'col_62' => '',
    'col_63' => '',
    'col_64' => '',
    'col_65' => '',
    'col_66' => '',
    'col_67' => '',
    'col_68' => '',
    'col_69' => '',
    'col_70' => '',
    'col_71' => '',
    'col_72' => '',
    'col_73' => '',
    'col_74' => '',
    'col_75' => '',
    'col_76' => 'rsc_col_45',
    'col_77' => 'rsc_col_40',
    'col_78' => 'rsc_col_37',
    'col_79' => 'rsc_col_43',
    'col_80' => '',
    'col_81' => '',
    'col_82' => '',
    'col_83' => '',
    'col_84' => '',
    'col_85' => 'rsc_col_46',
    'col_86' => '',
    'col_87' => '',
    'col_88' => '',
    'col_89' => '',
    'col_90' => '',
    'col_91' => '',
    'col_92' => '',
    'col_93' => '',
    'col_94' => '',
    'col_95' => '',
    'col_96' => '',
    'col_97' => '',
    'col_98' => '',
    'col_99' => '',
    'col_100' => '',
    'col_101' => '',
    'col_102' => '',
    'col_103' => '',
    'col_104' => '',
    'col_105' => '',
    'col_106' => '',
    'col_107' => '',
    'col_108' => '',
    'col_109' => '',
    'col_110' => '',
    'col_111' => '',
    'col_112' => '',
    'col_113' => '',
    'col_114' => '',
    'col_115' => '',
    'col_116' => '',
    'col_117' => '',
    'col_118' => '',
    'col_119' => '',
    'col_120' => '',
    'col_121' => '',
    'col_122' => '',
    'col_123' => '',
    'col_124' => '',
    'col_125' => '',
    'col_126' => '',
    'col_127' => '',
    'col_128' => '',
    'col_129' => 'rsc_col_9',
    'col_130' => '',
    'col_131' => '',
    'col_132' => '',
    'col_133' => '',
    'col_134' => '',
    'col_135' => '',
    'col_136' => '',
    'col_137' => 'rsc_col_28',
    'col_138' => '',
    'col_139' => 'rsc_col_4',
];
?>

@extends('adminview.master')

@section('bodyarea')
    <!-- partial -->

    <div class="main-panel">

        <div class="content-wrapper">

            <div class="row">

                <div class="col-sm-12">

                    <div class="home-tab">

                        <div class="tab-content tab-content-basic">

                            <div class="tab-pane fade show active" id="overview" role="tabpanel" aria-labelledby="overview">



                                <div class="row">



                                    <div class="col-lg-12 grid-margin stretch-card">

                                        <div class="card">

                                            <div class="card-body">



                                                @if ($message = Session::get('success'))
                                                    <div class="alert alert-success" role="alert">

                                                        <strong>Success!</strong> {{ $message }}

                                                    </div>
                                                @endif

                                                {!! Session::forget('success') !!}



                                                <div class="row">

                                                    <div class="col-md-4">
                                                        <h4 class="card-title">SURUGA Template Data</h4>
                                                    </div>

                                                    <div class="col-md-8">

                                                        <?php /* ?> ?>

                                                        <a href="{{ route('exportexcel', 'xls') }}"><button
                                                                class="btn btn-warning text-light">Download Template
                                                                xls</button></a>

                                                        <a href="{{ route('exportexcel', 'xlsx') }}"><button
                                                                class="btn btn-danger text-light">Download Template
                                                                xlsx</button></a>

                                                        <a href="{{ route('exportexcel', 'csv') }}"><button
                                                                class="btn btn-dark text-light">Download Template
                                                                CSV</button></a>

                                                        <?php */ ?>
                                                        <a href="{{ route('exporter') }}?action=remove&ids=0"
                                                            class="btn btn-warning text-dark" style="float:right"
                                                            onclick="return confirm('Do you want remvoe all records ?')">Remove
                                                            All List</a>

                                                        <a href="sdf"
                                                            class="btn removeallbtn disabled btn-secondary text-dark"
                                                            style="float:right"
                                                            onclick="return confirm('Do you want remvoe selected records ?')">Remove
                                                            Selected List</a>

                                                        <a href="{{ route('exportexcel', ['csv', 'template']) }}"
                                                            style="float:right"><button
                                                                class="btn btn-dark text-light">Download Template
                                                                XLSX</button></a>


                                                    </div>

                                                </div>

                                                <div class="table-responsive pt-3">

                                                    <table class="table table-bordered">

                                                        <thead>

                                                            <tr>

                                                                <th>SN</th>

                                                                <th>ACTION</th>

                                                                <th>Seller GSTIN *</th>

                                                                <th>Seller legal Name</th>

                                                                <th>Seller Trade Name</th>

                                                                <th>Seller Addr1</th>

                                                                <th>Seller Addr2</th>

                                                                <th>Seller Location</th>

                                                                <th>Seller Pin code</th>

                                                                <th>Seller state</th>

                                                                <th>Seller Phone number</th>

                                                                <th>Seller email ID</th>

                                                                <th>Supply type code *</th>

                                                                <th>Reverse Charge</th>

                                                                <th>E-comm GSTIN</th>

                                                                <th>IGST on Intra</th>

                                                                <th>Document type *</th>

                                                                <th>Document Number *</th>

                                                                <th>Document Date (DD/MM/YYYY) *</th>

                                                                <th>Buyer GSTIN *</th>

                                                                <th>Buyer legal Name *</th>

                                                                <th>Buyer Trade Name</th>

                                                                <th>Buyer POS *</th>

                                                                <th>Buyer Addr1 *</th>

                                                                <th>Buyer Addr2</th>

                                                                <th>Buyer Location *</th>

                                                                <th>Buyer Pin code</th>

                                                                <th>Buyer state*</th>

                                                                <th>Buyer Phone number</th>

                                                                <th>Buyer email ID</th>

                                                                <th>Dispatch Name</th>

                                                                <th>Dispatch Addr1</th>

                                                                <th>Dispatch Addr2</th>

                                                                <th>Dispatch Location</th>

                                                                <th>Dispatch Pin code</th>

                                                                <th>Dispatch state</th>

                                                                <th>Shipping GSTIN</th>

                                                                <th>Shipping legal Name</th>

                                                                <th>Shipping Trade Name</th>

                                                                <th>Shipping Addr1</th>

                                                                <th>Shipping Addr2</th>

                                                                <th>Shipping Location</th>

                                                                <th>Shipping Pin code</th>

                                                                <th>Shipping state</th>

                                                                <th>SI.NO. *</th>

                                                                <th>Product Description</th>

                                                                <th>Is_Service *</th>

                                                                <th>HSN Code *</th>

                                                                <th>Bar code</th>

                                                                <th>Quantity *</th>

                                                                <th>Free Quantity</th>

                                                                <th>UNIT *</th>

                                                                <th>Unit Price *</th>

                                                                <th>Gross Amount *</th>

                                                                <th>Discount</th>

                                                                <th>Pre tax value</th>

                                                                <th>Taxable value *</th>

                                                                <th>GST Rate (%) *</th>

                                                                <th>Sgst Amt (Rs)</th>

                                                                <th>Cgst Amt (Rs)</th>

                                                                <th>Igst Amt (Rs)</th>

                                                                <th>Cess Rate (%)</th>

                                                                <th>Cess Amt Adval (Rs)</th>

                                                                <th>Cess Non-Adval Amt (Rs)</th>

                                                                <th>State Cess Rate (%)</th>

                                                                <th>State Cess Amt Adval (Rs)</th>

                                                                <th>State Cess Non-Adval Amt (Rs)</th>

                                                                <th>Other Charges</th>

                                                                <th>Item Total *</th>

                                                                <th>Order Line reference</th>

                                                                <th>Orgin country</th>

                                                                <th>Unique Item SI. No.</th>

                                                                <th>Batch Name</th>

                                                                <th>Batch Expiry Dt</th>

                                                                <th>Warranty Dt</th>

                                                                <th>Attribute Details of the items</th>

                                                                <th>Attribute Value of the item</th>

                                                                <th>Total Taxable value *</th>

                                                                <th>SGST Amt</th>

                                                                <th>CGST Amt</th>

                                                                <th>IGST Amt</th>

                                                                <th>Cess Amt</th>

                                                                <th>State Cess Amt</th>

                                                                <th>Discount</th>

                                                                <th>Other Charges</th>

                                                                <th>Round Off</th>

                                                                <th>Total Invoice value *</th>

                                                                <th>Total Invoice value in Additional Curr</th>

                                                                <th>Shipping Bill No.</th>

                                                                <th>Shipping Bill Dt</th>

                                                                <th>Port</th>

                                                                <th>Supplier Refund</th>

                                                                <th>Foreign Currency</th>

                                                                <th>Country Code</th>

                                                                <th>Export Duty Amount</th>

                                                                <th>Trans ID</th>

                                                                <th>Trans Name</th>

                                                                <th>Trans Mode</th>

                                                                <th>Distance</th>

                                                                <th>Trans Doc No.</th>

                                                                <th>Trans Doc Date</th>

                                                                <th>Vehicle No.</th>

                                                                <th>Vehicle Type</th>

                                                                <th>Payee Name</th>

                                                                <th>Account Number</th>

                                                                <th>Mode</th>

                                                                <th>Branch/IFSC code</th>

                                                                <th>Term of Payment</th>

                                                                <th>Payment Instruction</th>

                                                                <th>Credit Transfer</th>

                                                                <th>Direct Debit</th>

                                                                <th>Credit Days</th>

                                                                <th>Paided amount</th>

                                                                <th>Due amount</th>

                                                                <th>Remarks</th>

                                                                <th>Invoice Period Start Date</th>

                                                                <th>Invoice Period End Date</th>

                                                                <th>Original Invoice</th>

                                                                <th>Preceding Invoice Date</th>

                                                                <th>Other Reference</th>

                                                                <th>Receipt Advice No.</th>

                                                                <th>Date of Receipt Advice</th>

                                                                <th>Lot/Batch Reference No.</th>

                                                                <th>Contract Reference Number</th>

                                                                <th>Any other reference</th>

                                                                <th>Project Reference Number</th>

                                                                <th>Vendor PO Reference Number</th>

                                                                <th>Vendor's PO Reference Date</th>

                                                                <th>Supporting document URL</th>

                                                                <th>Supporting document in Base64 Format</th>

                                                                <th>Any additional information</th>

                                                                <th>Custom</th>

                                                                <th>Custom2</th>

                                                                <th>Custom3</th>

                                                                <th>Custom4</th>

                                                                <th>Custom5</th>

                                                                <th>Custom6</th>

                                                                <th>Custom7</th>

                                                                <th>Custom8</th>

                                                                <th>Custom9</th>

                                                                <th>Custom10</th>



                                                            </tr>

                                                        </thead>

                                                        <tbody>

                                                            @php($sn = 0)

                                                            @foreach ($exceldata as $getexcel)
                                                                @php($sn++)

                                                                <tr>

                                                                    <td>{{ $sn }}</td>

                                                                    <td>
                                                                        <input type="checkbox" class="multiselection"
                                                                            value="{{ $getexcel->rsc_id }}">

                                                                        <a href="{{ route('exporter') }}?action=remove&ids={{ $getexcel->rsc_id }}"
                                                                            onclick="return confirm('Do you wnat remove this record?')"
                                                                            class="btn btn-danger text-light singleremove">Remove</a>
                                                                    </td>

                                                                    @for ($i = 1; $i <= 139; $i++)
                                                                        <td>
                                                                            <?php
                                                                            if ($tempArray['col_' . $i] != '') {
                                                                                $tempCol = explode('-', $tempArray['col_' . $i]);
                                                                                if (count($tempCol) > 0) {
                                                                                    foreach ($tempCol as $getColl) {
                                                                                        echo $getexcel->$getColl . '  ';
                                                                                    }
                                                                                }
                                                                            }
                                                                            if('col_' . $i=='col_11'){
                                                                                echo "B2B";
                                                                            }
                                                                            
                                                                            ?>
                                                                            <!-- {{ $getexcel->{'rsc_col_' . $i} }} -->
                                                                        </td>
                                                                    @endfor

                                                                </tr>
                                                            @endforeach

                                                        </tbody>

                                                    </table>

                                                </div>

                                                <div style="float:right">
                                                    {{ $exceldata->links('vendor.pagination.default') }}
                                                </div>

                                            </div>

                                        </div>

                                    </div>





                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

        <!-- content-wrapper ends -->
        <script>
            $(document).ready(function() {
                $('.multiselection').on('change', function() {
                    var selecteditem = [];
                    $.each($("input:checkbox[class=multiselection]:checked"), function() {
                        selecteditem.push($(this).val());
                    });
                    console.log(selecteditem);
                    var checkeditems = selecteditem.join("-");

                    if (checkeditems.length >= 3) {
                        $(".removeallbtn").attr('href', "{{ route('exporter') }}?action=remove&ids=" +
                            checkeditems);
                        $(".singleremove").removeClass('text-light btn-danger');
                        $(".singleremove").addClass('disabled text-dark btn-secondary text-dark');
                        $(".removeallbtn").addClass('text-light btn-danger');
                        $(".removeallbtn").removeClass('disabled text-dark btn-secondary text-dark');
                    } else {
                        $(".removeallbtn").attr('href', '#');
                        $(".removeallbtn").removeClass('text-light btn-danger');
                        $(".removeallbtn").addClass('disabled text-dark btn-secondary text-dark');
                        $(".singleremove").addClass('text-light btn-danger');
                        $(".singleremove").removeClass('disabled text-dark btn-secondary text-dark');
                    }
                });
            });
        </script>
    @endsection
