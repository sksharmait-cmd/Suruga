@extends('adminview.master')

@section('bodyarea')





      <!-- partial -->

      <div class="main-panel">

        <div class="content-wrapper">

          <div class="row">

            <div class="col-sm-12">

              <div class="home-tab">

                <div class="tab-content tab-content-basic">

                  <div class="tab-pane fade show active" id="overview" role="tabpanel" aria-labelledby="overview">

                    

                    <div class="row">



                    <div class="col-lg-12 grid-margin stretch-card">

              <div class="card">

                <div class="card-body"> 



        <div class="alert alert-warning" id="waiterror" style="display:none;" role="alert">dasfdasf</div>



                  <div class="row">

                    <div class="col-md-2"><h4 class="card-title">SURUGA Row Data</h4></div>

                    <div class="col-md-5">

    <?php /* ?>

    <a href="{{ route('exportexcel', 'xls') }}"><button class="btn btn-warning text-light">Download Row xls</button></a>

    <a href="{{ route('exportexcel', 'xlsx') }}"><button class="btn btn-danger text-light">Download Row xlsx</button></a>

    <?php */ ?>
  
    <a href="{{route('importer')}}?action=remove&ids=0" class="btn btn-warning text-dark" onclick="return confirm('Do you want remvoe all records ?')">Remove All List</a>
    
    <a href="sdf" class="btn removeallbtn disabled btn-secondary text-dark" onclick="return confirm('Do you want remvoe selected records ?')">Remove Selected List</a>

    <a href="{{ route('exportexcel', ['csv', 'row']) }}"><button class="btn btn-dark text-light">Download Row CSV</button></a>

</div>

<div class="col-md-5" style="position: relative;">
<p style="margin: 0; padding: 0; position: absolute; right: 24px; top: -22px; color: #f00;">Download Sample CSV and put data according to column.</p>
    <form action="{{ route('importexcel') }}" class="form-horizontal" method="post" id="importdataform" enctype="multipart/form-data">

        {{ csrf_field() }}

        <a href="{{url('/assets/images/SURUGA_Data_Column_Sample.csv')}}" download style="float: right; color: #fff; padding: 3px 5px; text-align: center; background: #9c9c9c; border-radius: 5px;"><i class="menu-icon mdi mdi-download"></i></a>

        <button class="btn btn-success text-light" style="float:right; margin-left: 10px;">Import Row File</button>

        <input type="file" name="import_file" class="form-control pull-right" style="max-width: 50%;float:right;" />
    </form>    

                    </div>

                  </div>

                  <div class="table-responsive pt-3">

                    <table class="table table-bordered">

                      <thead>

                        <tr>

<th>SN</th>

<th>ACTION</th>

<th>Forwarder_Invoice_No</th>

<th>Supplier_Ship_Date</th>

<th>ECAL_Customer_Code</th>

<th>ECAL_SEQ</th>

<th>ECALL_Code</th>

<th>Product_Name</th>

<th>Product_Code</th>

<th>Orgin</th>

<th>PO_No</th>

<th>Quantity</th>

<th>Unit</th>

<th>Unit_Price</th>

<th>Currency</th>

<th>Total_Amount</th>

<th>Unit_Weight</th>

<th>Total_Net_Weight</th>

<th>Weight_Unit</th>

<th>Inner-7</th>

<th>HS_Code</th>

<th>Non_Commercial_Flag</th>

<th>Customs_Date</th>

<th>Bill_Of_Entry_No</th>

<th>Landing_Charge</th>

<th>Assessed_Value</th>

<th>BCD_Rate</th>

<th>BCD_Amount</th>

<th>CVD_Rate</th>

<th>CVD_Amount</th>

<th>Edn_CESS_Rate</th>

<th>Edn_CESS_Amount</th>

<th>ACD_Rate</th>

<th>ACD_Amount</th>

<th>Duty_Amount</th>

<th>Offset_Amount</th>




                        </tr>

                      </thead>

                      <tbody> 

                        @php($sn=0)

                      @foreach($exceldata as $getexcel)

                      @php($sn++)

        <tr>

        <td>{{$sn}}</td>

        <td>
          <input type="checkbox" class="multiselection" value="{{$getexcel->rsc_id}}">

          <a href="{{route('importer')}}?action=remove&ids={{$getexcel->rsc_id}}" onclick="return confirm('Do you wnat remove this record?')" class="btn btn-danger text-light singleremove">Remove</a>
        </td>

        @for($i=1; $i<=34; $i++)

            <td>{{ $getexcel->{'rsc_col_'.$i} }}</td>

        @endfor

        </tr>

    @endforeach

                      </tbody>

                    </table>
                  </div>
                  <div style="float:right">
                  {{$exceldata->links('vendor.pagination.default')}}
                  </div>
                </div>

              </div>

            </div>

                    

                    

                    </div>

                  </div>

                </div>

              </div>

            </div>

          </div>

        </div>

        <!-- content-wrapper ends -->

<script type="text/javascript">



$(document).ready(function(){



  $('#importdataform').submit(function (e) {

	

    

    e.preventDefault();

	var form = $('#importdataform')[0];

	var data = new FormData(form);

	var waiterror = $("#waiterror");

	waiterror.html('');

	waiterror.css('display', 'none');

	waiterror.removeClass('alert-danger');

	waiterror.removeClass('alert-success');

	waiterror.removeClass('alert-warning');



	$.ajax({

		type: 'POST',

		enctype: 'multipart/form-data',

		url: "{{ route('importexcel') }}",

		data: data,

		processData: false,

		contentType: false,

		cache: false,

		beforeSend: function(){

			waiterror.html('Please wait data is inserting..');

			waiterror.addClass('alert-warning');

			waiterror.css('display', 'block');

		},

		success: function (response) {

			waiterror.removeClass('alert-warning');

			if(response=='Success'){

				waiterror.html("<strong>Success!</strong> Your file is imported successfully in database.");

				waiterror.addClass('alert-success');

        setTimeout(() => {

          location.reload();

        }, 2000);

			}

			else{

				waiterror.html(response);

				waiterror.addClass('alert-danger');

			}

		}

	});

  

  



});



$('.multiselection').on('change', function() {
var selecteditem = [];
$.each($("input:checkbox[class=multiselection]:checked"), function() {
  selecteditem.push($(this).val());
});
var checkeditems = selecteditem.join("-");
if (checkeditems.length>=3) {
  $(".removeallbtn").attr('href',"{{route('importer')}}?action=remove&ids="+checkeditems);
  $(".singleremove").removeClass('text-light btn-danger');
  $(".singleremove").addClass('disabled text-dark btn-secondary text-dark');
  $(".removeallbtn").addClass('text-light btn-danger');
  $(".removeallbtn").removeClass('disabled text-dark btn-secondary text-dark');
}else{
  $(".removeallbtn").attr('href','#');
  $(".removeallbtn").removeClass('text-light btn-danger');
  $(".removeallbtn").addClass('disabled text-dark btn-secondary text-dark');
  $(".singleremove").addClass('text-light btn-danger');
  $(".singleremove").removeClass('disabled text-dark btn-secondary text-dark');
}
});








});



</script>



@endsection