<!DOCTYPE html>

<html lang="en">



<head>

  <!-- Required meta tags -->

  <meta charset="utf-8">

  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>Suruga India</title>

  <!-- endinject -->

  <!-- Plugin css for this page -->

  <!-- End plugin css for this page -->

  <!-- inject:css -->

  <link rel="stylesheet" href="assets/css/vertical-layout-light/style.css">

  <!-- endinject -->

</head>



<body>

  <div class="container-scroller">

    <div class="container-fluid page-body-wrapper full-page-wrapper">

      <div class="content-wrapper d-flex align-items-center auth px-0">

        <div class="row w-100 mx-0">

          <div class="col-lg-4 mx-auto">

            <div class="auth-form-light text-left py-5 px-4 px-sm-5">

              <div class="brand-logo">

                <!-- <img src="assets/images/logo.svg" alt="logo"> -->

                <strong>Admin</strong>

              </div>

              <h4>Hello! let's get started</h4>

              <h6 class="fw-light">Sign in to continue.</h6>

              <form id="logincrmform" method="post">

              @csrf

                <div class="form-group">

                  <input type="text" name="emailid" class="form-control form-control-lg" placeholder="Your Email Address" />

                </div>

                <div class="form-group">

                <input type="password" name="password" class="form-control form-control-lg" placeholder="Password" />

                </div>

                <div class="mt-3">

                  <input type="submit" name="" value="SIGN IN" class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn">

                    <div class="alert alert-secondary" id="loginError" style="display: none;"></div>

                </div>

                

              </form>

            </div>

          </div>

        </div>

      </div>

      <!-- content-wrapper ends -->

    </div>

    <!-- page-body-wrapper ends -->

  </div>

  <!-- container-scroller -->

</body>



<script type="text/javascript" src="assets/js/jquery.min.js"></script>

<script type="text/javascript">

  $(document).ready(function(){



base_url = "{{url('/')}}";

    $('#logincrmform').submit(function(e){

      e.preventDefault();

      $('#loginError').removeClass('alert-danger');

      $('#loginError').removeClass('alert-secondary');

  $.ajax({

    type : 'POST',

    url : base_url + '/loginadmin',

    data : $(this).serialize(),

    beforeSend: function () {

      $('#loginError').css("display", "block");

      $('#loginError').text("Please wait..");

    },

    success : function(response){

      

      if(response=='Veryfied')

      {

          $('#loginError').css('display','none');

          $('#loginError').removeClass('alert-danger');

          $('#loginError').html();

          setTimeout(function(){ window.location="{{Route('dashboard')}}"; });

      }

      else

      {

          $('#loginError').css('display','block');

          $('#loginError').addClass('alert-danger');

          $('#loginError').text(response);

      }

    }

  });



    });





  });

</script>



</html>

