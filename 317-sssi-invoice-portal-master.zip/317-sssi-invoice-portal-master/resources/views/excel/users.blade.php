<table>
    <thead>
    <tr>
        <th>Name</th>
        <th>Email</th>
    </tr>
    </thead>
    <tbody>
    @foreach($users as $user)
        <tr>
            <td>{{ $user->name_on_card }}</td>
            <td>{{ $user->card_no }}</td>
        </tr>
    @endforeach
    </tbody>
</table>