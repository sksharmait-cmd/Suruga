<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CheckLogin extends Model
{
    protected $table = 'rst_administrator';
    protected $primaryKey = 'rsc_id';
    use HasFactory;
}
