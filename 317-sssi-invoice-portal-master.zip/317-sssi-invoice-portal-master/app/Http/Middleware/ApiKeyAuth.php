<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

/**
 * API key auth for SSSi / machine clients (independent of web session login).
 */
class ApiKeyAuth
{
    public function handle(Request $request, Closure $next)
    {
        $expected = (string) config('go4gst.api_key', '');
        if ($expected === '') {
            return response()->json([
                'ok' => false,
                'message' => 'GO4GST_API_KEY is not configured on the server.',
            ], 503);
        }

        $provided = (string) $request->header('X-API-Key', '');
        if ($provided === '' || !hash_equals($expected, $provided)) {
            return response()->json([
                'ok' => false,
                'message' => 'Unauthorized. Invalid or missing X-API-Key.',
            ], 401);
        }

        return $next($request);
    }
}
