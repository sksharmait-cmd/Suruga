<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\CheckLogin;
use Hash;
class AdminLogin extends Controller
{
    public function Login(){
        //return Hash::make('Admin@1234');
        return view('login');
    }

    public function AdminLoginAuth(Request $request){
        $validator = Validator::make($request->all(), [
            'emailid' => 'required',
            'password' => 'required',
        ]);

        if ($validator->fails()) {
            foreach($validator->errors()->all() as $getEr):
                return $getEr;
            endforeach;
        }
        else{
            $checkAdmin = CheckLogin::where('rsc_email','=',$request->emailid)->first();
            if($checkAdmin){
                if(Hash::check($request->password, $checkAdmin->rsc_password)):
                    $request->session()->put('adminkey', $checkAdmin->rsc_id);
                    return "Veryfied";
                else:
                    return "Sorry! Password is wrong";
                endif;
            }
            else{
                return "Sorry! This is not valid username.";
            }
        }
    }
}
