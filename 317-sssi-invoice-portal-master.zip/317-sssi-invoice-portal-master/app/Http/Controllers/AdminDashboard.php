<?php



namespace App\Http\Controllers;



use App\Models\Transaction;

use Illuminate\Http\Request;

use App\Exports\TransactionsExport;

use App\Imports\TransactionsImport;



use Illuminate\Support\Facades\DB;



class AdminDashboard extends Controller

{
    
    public function Dashboard(){

        return view('adminview.dashboard');

    }
    

    public function Importlist(Request $request){

        if($request->input('action')=='remove' && $request->input('ids')>=0){

            if($request->input('ids')==0){

                Transaction::whereNotNull('rsc_id')->delete();

            }else{

                Transaction::whereIn('rsc_id', explode('-',$request->input('ids')))->delete();   

            }

            return redirect(Route('importer'));

        }

        return view('adminview.importdata', ['exceldata' => Transaction::paginate(50)]);

    }

    public function Exportlist(Request $request){ 

        if($request->input('action')=='remove' && $request->input('ids')>=0){

            if($request->input('ids')==0){

                Transaction::whereNotNull('rsc_id')->delete();

            }else{

                Transaction::whereIn('rsc_id', explode('-',$request->input('ids')))->delete();   

            }

            return redirect(Route('exporter'));

        }

        return view('adminview.exportdata', ['exceldata' => Transaction::paginate(50)]);

    }



    public function exportExcel($type, $data) 

    {

        if($data=='row'){

            $file = 'Row_data_';

        }

        else{

            $file = 'Invoice_Template_';

        }
        /*return view('adminview.template', [
            'exceldata' => \App\Models\Transaction::all()->toArray()
        ]);*/
        return \Excel::download(new TransactionsExport, $file.date('Y-m-d_H:i:s').'.xlsx');

    }



    public function importExcel(Request $request) 

    {
        if(empty($request->file('import_file'))){
            return "Please select .CSV file.";
        }  else{
            $fileNm = explode('.',$request->file('import_file')->getClientOriginalName());
        if(strtolower(end($fileNm))=='csv'){

            $file_path = $request->import_file->getPathName();
            $tmpDir = storage_path('app/tmp');
            if (!is_dir($tmpDir)) {
                mkdir($tmpDir, 0777, true);
            }
            $stored = $tmpDir . DIRECTORY_SEPARATOR . 'web_import.csv';
            if ($file_path && is_file($file_path)) {
                copy($file_path, $stored);
                $file_path = $stored;
            }

            $file = fopen($file_path, 'r');
            $kn = 0;
            while (($line = fgetcsv($file)) !== FALSE) {
                $kn++;
              //$line is an array of the csv elements
              if($kn>=2){
                if(strtoupper($line[2])!='H' && strtoupper($line[2])!='K' && strtoupper($line[2])!='M'){
                    echo "Oops! ECAL Customer Code is missing.";
                    fclose($file);
                    exit();
                }
              }
            }

            fclose($file);

            \Excel::import(new TransactionsImport, $file_path);

            //\Session::put('success', 'Your file is imported successfully in database.');

            return 'Success';

        }

        else{

            return "Please select .CSV file.";

        }

        }

    }



    public function Logoutadmin(){

        if(session()->has('adminkey')){

            session()->pull('adminkey');

        }

        return redirect('/');

    }

}

