<?php

namespace App\Http\Controllers;

use App\Exceptions\BufferBusyException;
use App\Exports\Go4gstTemplateExport;
use App\Imports\TransactionsImport;
use App\Models\Transaction;
use App\Services\MossCsvParser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;

/**
 * Machine API for SSSi Tool.
 *
 * Production (GO4GST_SKIP_DB=false, default):
 *   clear buffer → import CSV into rst_excel_row_data → export 139 XLSX
 *   (same columnFormats as web Download Template).
 *
 * Local/file test (GO4GST_SKIP_DB=true):
 *   parse CSV in memory → build 139 XLSX (no DB). API key auth still required.
 *   clear/import/export-only endpoints return 503 until DB is available.
 *
 * rst_excel_row_data is a single shared buffer, so every sequence that clears it and
 * reads it back runs under a named lock and a transaction. Without that, two clients
 * converting at the same time would each receive the other's rows merged into their
 * 139-column file, with invoice level totals covering both invoices.
 *
 * Web UI controllers are unchanged.
 */
class Go4gstApiController extends Controller
{
    private const LOCK_NAME = 'go4gst_excel_row_buffer';

    /**
     * Atomic convert: POST /api/v1/go4gst/convert
     * multipart field: file (CSV 34 columns)
     */
    public function convert(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'file' => 'required|file',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'ok' => false,
                'message' => $validator->errors()->first(),
            ], 422);
        }

        $file = $request->file('file');
        $ext = strtolower($file->getClientOriginalExtension());
        if ($ext !== 'csv') {
            return response()->json([
                'ok' => false,
                'message' => 'Please select a .CSV file.',
            ], 422);
        }

        $localCsv = $this->persistUpload($file);
        if ($localCsv === '') {
            return response()->json([
                'ok' => false,
                'message' => 'Could not store the uploaded CSV.',
            ], 422);
        }

        $parser = new MossCsvParser();
        [$ok, $parsedRows] = $parser->parseFile($localCsv);
        if ($ok !== true) {
            return response()->json([
                'ok' => false,
                'message' => $ok,
            ], 422);
        }

        $skipDb = $this->skipDb();
        $mode = 'db';

        if ($skipDb) {
            // File-only test path: same builder, no Transaction / Excel::import
            $rows = $parsedRows;
            $mode = 'skip_db';
        } else {
            // Production path — identical to web clear-all + importExcel
            try {
                $rows = $this->withBufferLock(function () use ($localCsv) {
                    Transaction::whereNotNull('rsc_id')->delete();
                    \Excel::import(new TransactionsImport, $localCsv);
                    return Transaction::orderBy('rsc_id')->get()->toArray();
                });
            } catch (BufferBusyException $e) {
                return response()->json([
                    'ok' => false,
                    'message' => 'Another conversion is in progress. Try again in a moment.',
                ], 409);
            } catch (\Throwable $e) {
                return response()->json([
                    'ok' => false,
                    'message' => 'Database import failed: ' . $e->getMessage(),
                    'hint' => 'Set GO4GST_SKIP_DB=true for file-only testing without MySQL.',
                ], 503);
            }
            if (count($rows) === 0) {
                return response()->json([
                    'ok' => false,
                    'message' => 'Import succeeded but no rows were stored.',
                ], 422);
            }
        }

        try {
            $export = new Go4gstTemplateExport($rows);
        } catch (\Throwable $e) {
            return response()->json([
                'ok' => false,
                'message' => $e->getMessage(),
            ], 422);
        }

        $base = pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME);
        $outName = 'GO4GST_139_' . $base . '.xlsx';

        return $this->downloadTemplate($export, $outName, $rows, $mode);
    }

    /**
     * DELETE /api/v1/go4gst/rows — same as web clear-all (requires DB).
     */
    public function clearRows()
    {
        if ($this->skipDb()) {
            return $this->dbRequiredResponse('clear');
        }

        try {
            $deleted = $this->withBufferLock(function () {
                return Transaction::whereNotNull('rsc_id')->delete();
            });
        } catch (BufferBusyException $e) {
            return $this->busyResponse();
        }

        return response()->json([
            'ok' => true,
            'deleted' => $deleted,
        ]);
    }

    /**
     * POST /api/v1/go4gst/import — same as web importExcel (requires DB).
     */
    public function importOnly(Request $request)
    {
        if ($this->skipDb()) {
            return $this->dbRequiredResponse('import');
        }

        $validator = Validator::make($request->all(), [
            'file' => 'required|file',
        ]);
        if ($validator->fails()) {
            return response()->json(['ok' => false, 'message' => $validator->errors()->first()], 422);
        }

        $file = $request->file('file');
        if (strtolower($file->getClientOriginalExtension()) !== 'csv') {
            return response()->json(['ok' => false, 'message' => 'Please select a .CSV file.'], 422);
        }

        $localCsv = $this->persistUpload($file);
        if ($localCsv === '') {
            return response()->json(['ok' => false, 'message' => 'Could not store the uploaded CSV.'], 422);
        }

        $parser = new MossCsvParser();
        [$ok] = $parser->parseFile($localCsv);
        if ($ok !== true) {
            return response()->json(['ok' => false, 'message' => $ok], 422);
        }

        try {
            $count = $this->withBufferLock(function () use ($localCsv) {
                \Excel::import(new TransactionsImport, $localCsv);
                return Transaction::count();
            });
        } catch (BufferBusyException $e) {
            return $this->busyResponse();
        }

        return response()->json([
            'ok' => true,
            'message' => 'Success',
            'row_count' => $count,
        ]);
    }

    /**
     * GET /api/v1/go4gst/export — export buffer (requires DB).
     */
    public function exportOnly()
    {
        if ($this->skipDb()) {
            return $this->dbRequiredResponse('export');
        }

        $rows = Transaction::orderBy('rsc_id')->get()->toArray();
        if (count($rows) === 0) {
            return response()->json([
                'ok' => false,
                'message' => 'No rows in buffer. Import a CSV first.',
            ], 422);
        }

        try {
            $export = new Go4gstTemplateExport($rows);
        } catch (\Throwable $e) {
            return response()->json(['ok' => false, 'message' => $e->getMessage()], 422);
        }

        $outName = 'GO4GST_139_export_' . date('Ymd_His') . '.xlsx';
        return $this->downloadTemplate($export, $outName, $rows, 'db');
    }

    private function downloadTemplate(Go4gstTemplateExport $export, string $outName, array $rows, string $mode)
    {
        return Excel::download($export, $outName, \Maatwebsite\Excel\Excel::XLSX, [
            'X-GO4GST-Rows' => (string) count($rows),
            'X-GO4GST-ECAL' => (string) ($rows[0]['rsc_col_3'] ?? ''),
            'X-GO4GST-Mode' => $mode,
        ]);
    }

    /**
     * Serialises access to the rst_excel_row_data buffer across processes.
     *
     * @throws BufferBusyException when the lock cannot be taken in time
     * @return mixed whatever $fn returns
     */
    private function withBufferLock(callable $fn)
    {
        $timeout = (int) config('go4gst.lock_timeout', 15);
        $got = DB::selectOne('SELECT GET_LOCK(?, ?) AS acquired', [self::LOCK_NAME, $timeout]);
        if (!$got || (int) $got->acquired !== 1) {
            throw new BufferBusyException();
        }

        try {
            return DB::transaction($fn);
        } finally {
            DB::select('SELECT RELEASE_LOCK(?)', [self::LOCK_NAME]);
        }
    }

    private function busyResponse()
    {
        return response()->json([
            'ok' => false,
            'message' => 'Another conversion is in progress. Try again in a moment.',
        ], 409);
    }

    /** Copy the IIS/PHP temp upload to storage so Maatwebsite still has a real path. */
    private function persistUpload($file): string
    {
        $dir = storage_path('app/tmp');
        if (!is_dir($dir) && !@mkdir($dir, 0777, true) && !is_dir($dir)) {
            return '';
        }
        $dest = $dir . DIRECTORY_SEPARATOR . 'upload_' . bin2hex(random_bytes(6)) . '.csv';
        $src = $file->getPathname();
        if ($src && is_file($src)) {
            return copy($src, $dest) ? $dest : '';
        }
        $uploaded = $file->storeAs('tmp', basename($dest));
        return $uploaded ? storage_path('app/' . $uploaded) : '';
    }

    private function skipDb(): bool
    {
        return (bool) config('go4gst.skip_db', false);
    }

    private function dbRequiredResponse(string $action)
    {
        return response()->json([
            'ok' => false,
            'message' => "Endpoint '{$action}' requires database. GO4GST_SKIP_DB=true (file-only mode).",
            'hint' => 'Use POST /api/v1/go4gst/convert for file-only testing, or set GO4GST_SKIP_DB=false with MySQL.',
        ], 503);
    }
}
