<?php

namespace App\Services;

/**
 * Builds the 139-column GO4GST import CSV from rst_excel_row_data rows.
 *
 * Mapping mirrors resources/views/adminview/template.blade.php, so the API output
 * matches the template an operator downloads from the web UI, with three differences:
 *  - Product Description limited to 30 characters (SOP slide 14, done by hand today)
 *  - Document Date from Supplier_Ship_Date instead of the export day, so a template
 *    exported later than the shipment still carries the real invoice date
 *  - Buyer POS / Buyer state / Shipping state written as 2 digits ("06")
 *
 * XLSX for the convert API uses the same columnFormats as TransactionsExport
 * (portal Download Template): state 00, amounts 0.00.
 */
class Go4gstTemplateCsvBuilder
{
    public const TEXT_MAX = 30;

    /** @var string[] */
    public static $headers = [
        'Seller GSTIN *', 'Seller legal Name', 'Seller Trade Name', 'Seller Addr1', 'Seller Addr2',
        'Seller Location', 'Seller Pin code', 'Seller state', 'Seller Phone number', 'Seller email ID',
        'Supply type code *', 'Reverse Charge', 'E-comm GSTIN', 'IGST on Intra', 'Document type *',
        'Document Number *', 'Document Date (DD/MM/YYYY) *', 'Buyer GSTIN *', 'Buyer legal Name *',
        'Buyer Trade Name', 'Buyer POS *', 'Buyer Addr1 *', 'Buyer Addr2', 'Buyer Location *',
        'Buyer Pin code', 'Buyer state*', 'Buyer Phone number', 'Buyer email ID', 'Dispatch Name',
        'Dispatch Addr1', 'Dispatch Addr2', 'Dispatch Location', 'Dispatch Pin code', 'Dispatch state',
        'Shipping GSTIN', 'Shipping legal Name', 'Shipping Trade Name', 'Shipping Addr1',
        'Shipping Addr2', 'Shipping Location', 'Shipping Pin code', 'Shipping state', 'SI.NO. *',
        'Product Description', 'Is_Service *', 'HSN Code *', 'Bar code', 'Quantity *',
        'Free Quantity', 'UNIT *', 'Unit Price *', 'Gross Amount *', 'Discount', 'Pre tax value',
        'Taxable value *', 'GST Rate (%) *', 'Sgst Amt (Rs)', 'Cgst Amt (Rs)', 'Igst Amt (Rs)',
        'Cess Rate (%)', 'Cess Amt Adval (Rs)', 'Cess Non-Adval Amt (Rs)', 'State Cess Rate (%)',
        'State Cess Amt Adval (Rs)', 'State Cess Non-Adval Amt (Rs)', 'Other Charges', 'Item Total *',
        'Order Line reference', 'Orgin country', 'Unique Item SI. No.', 'Batch Name',
        'Batch Expiry Dt', 'Warranty Dt', 'Attribute Details of the items',
        'Attribute Value of the item', 'Total Taxable value *', 'SGST Amt', 'CGST Amt', 'IGST Amt',
        'Cess Amt', 'State Cess Amt', 'Discount', 'Other Charges', 'Round Off',
        'Total Invoice value *', 'Total Invoice value in Additional Curr', 'Shipping Bill No.',
        'Shipping Bill Dt', 'Port', 'Supplier Refund', 'Foreign Currency', 'Country Code',
        'Export Duty Amount', 'Trans ID', 'Trans Name', 'Trans Mode', 'Distance', 'Trans Doc No.',
        'Trans Doc Date', 'Vehicle No.', 'Vehicle Type', 'Payee Name', 'Account Number', 'Mode',
        'Branch/IFSC code', 'Term of Payment', 'Payment Instruction', 'Credit Transfer',
        'Direct Debit', 'Credit Days', 'Paided amount', 'Due amount', 'Remarks',
        'Invoice Period Start Date', 'Invoice Period End Date', 'Original Invoice',
        'Preceding Invoice Date', 'Other Reference', 'Receipt Advice No.', 'Date of Receipt Advice',
        'Lot/Batch Reference No.', 'Contract Reference Number', 'Any other reference',
        'Project Reference Number', 'Vendor PO Reference Number', "Vendor's PO Reference Date",
        'Supporting document URL', 'Supporting document in Base64 Format',
        'Any additional information', 'Custom', 'Custom2', 'Custom3', 'Custom4', 'Custom5',
        'Custom6', 'Custom7', 'Custom8', 'Custom9', 'Custom10',
    ];

    /**
     * @param  array<int,array<string,mixed>>  $exceldata
     */
    public function buildCsv(array $exceldata): string
    {
        if (!defined('BUYER')) {
            require_once config_path('constants.php');
        }

        $lines = [];
        $lines[] = $this->csvLine(self::$headers);

        $paybleAmount = 0.0;
        foreach ($exceldata as $row) {
            $paybleAmount += $this->num($row['rsc_col_14'] ?? 0);
        }
        $incTaxpaybleAmount = $paybleAmount + ($paybleAmount * 18) / 100;

        $sn = 0;
        foreach ($exceldata as $getexcel) {
            $sn++;
            $lines[] = $this->csvLine($this->buildRow($getexcel, $sn, $paybleAmount, $incTaxpaybleAmount));
        }

        // UTF-8 BOM for Excel
        return "\xEF\xBB\xBF" . implode("\r\n", $lines) . "\r\n";
    }

    /**
     * Rows for Maatwebsite XLSX (typed numbers so 0.00 / 00 formats match the portal download).
     *
     * @param  array<int,array<string,mixed>>  $exceldata
     * @return array<int,array<int,mixed>>
     */
    public function buildExcelRows(array $exceldata): array
    {
        if (!defined('BUYER')) {
            require_once config_path('constants.php');
        }

        $paybleAmount = 0.0;
        foreach ($exceldata as $row) {
            $paybleAmount += $this->num($row['rsc_col_14'] ?? 0);
        }
        $incTaxpaybleAmount = $paybleAmount + ($paybleAmount * 18) / 100;

        $out = [];
        $sn = 0;
        foreach ($exceldata as $getexcel) {
            $sn++;
            $out[] = $this->toExcelTypes($this->buildRow($getexcel, $sn, $paybleAmount, $incTaxpaybleAmount));
        }
        return $out;
    }

    /**
     * @param  array<int,mixed>  $row
     * @return array<int,mixed>
     */
    private function toExcelTypes(array $row): array
    {
        $money = [50, 51, 54, 56, 57, 58, 66, 75, 76, 77, 78, 84];
        foreach ($row as $i => $v) {
            if ($v === '') {
                $row[$i] = null;
            }
        }
        foreach ($money as $i) {
            if ($row[$i] === null || $row[$i] === '') {
                $row[$i] = null;
                continue;
            }
            $row[$i] = round($this->num($row[$i]), 2);
        }
        // Pins / phones / HSN / qty / GST% plus Buyer POS / Buyer state / Shipping state
        // (U, Z, AP) so format 00 applies like portal Download Template.
        // Seller state (H) stays as stored ("06") — blade writes the varchar as-is.
        foreach ([6, 8, 20, 24, 25, 26, 40, 41, 42, 45, 47, 55] as $i) {
            if ($row[$i] === null || $row[$i] === '') {
                continue;
            }
            if (is_numeric($row[$i]) && (float) $row[$i] == (int) $row[$i]) {
                $row[$i] = (int) $row[$i];
            }
        }
        return $row;
    }

    /**
     * @param  array<string,mixed>  $getexcel
     * @return string[]
     */
    private function buildRow(array $getexcel, int $sn, float $paybleAmount, float $incTaxpaybleAmount): array
    {
        $row = array_fill(0, 139, '');

        $ecal = strtoupper(trim((string) ($getexcel['rsc_col_3'] ?? '')));
        if (!isset(BUYER[$ecal])) {
            throw new \RuntimeException("Unknown ECAL Customer Code '{$ecal}'. Expected H, K or M.");
        }
        $buyer = BUYER[$ecal];

        $taxable = $this->num($getexcel['rsc_col_14'] ?? 0);
        $igst = ($taxable * 18) / 100;
        $gross = $taxable + $igst;
        $intra = ($ecal === 'H');

        $row[0] = (string) ($getexcel['surg_gst'] ?? '06AAPCS3407B1ZM');
        $row[1] = (string) ($getexcel['surg_legal_name'] ?? 'SURUGA INDIA PRIVATE LIMITED');
        $row[2] = (string) ($getexcel['surg_trade_ame'] ?? 'SURUGA INDIA PRIVATE LIMITED');
        $row[3] = (string) ($getexcel['surg_addr1'] ?? '');
        $row[4] = (string) ($getexcel['surg_addr2'] ?? '');
        $row[5] = (string) ($getexcel['surg_location'] ?? '');
        $row[6] = (string) ($getexcel['surg_pincode'] ?? '');
        $row[7] = (string) ($getexcel['surg_state'] ?? '');
        $phone = preg_replace('/[^0-9]/', '', (string) ($getexcel['surg_phone_number'] ?? ''));
        $row[8] = substr($phone, -12);
        $row[9] = (string) ($getexcel['surg_email'] ?? '');
        $row[10] = 'B2B';
        $row[11] = 'N';
        $row[14] = 'INV';
        $row[15] = (string) ($getexcel['rsc_col_1'] ?? '');
        $row[16] = $this->formatShipDate((string) ($getexcel['rsc_col_2'] ?? ''));

        $row[17] = $buyer['gst'];
        $row[18] = $buyer['lname'];
        $row[19] = $buyer['tname'];
        $row[20] = substr($buyer['gst'], 0, 2);
        $row[21] = $buyer['addr1'];
        $row[22] = $buyer['addr2'];
        $row[23] = $buyer['loc'];
        $row[24] = $buyer['pin'];
        $row[25] = $this->state2($buyer['state']);
        $row[26] = $buyer['phone'];
        $row[27] = $buyer['email'];

        $row[34] = $buyer['gst'];
        $row[35] = $buyer['lname'];
        $row[36] = $buyer['tname'];
        $row[37] = $buyer['addr1'];
        $row[38] = $buyer['addr2'];
        $row[39] = $buyer['loc'];
        $row[40] = $buyer['pin'];
        $row[41] = $this->state2($buyer['state']);

        $row[42] = (string) $sn;
        // Slide 14: product name max 30 chars
        $row[43] = $this->trim30((string) ($getexcel['rsc_col_6'] ?? ''));
        $row[44] = 'N';
        $row[45] = (string) ($getexcel['rsc_col_19'] ?? '');
        $row[46] = (string) ($getexcel['rsc_col_7'] ?? '');
        $row[47] = $this->numText($getexcel['rsc_col_10'] ?? '');
        $row[49] = 'NOS';
        $row[50] = $this->round2($this->num($getexcel['rsc_col_12'] ?? 0));
        $row[51] = $this->round2($taxable);
        $row[54] = $this->round2($taxable);
        $row[55] = '18';
        if ($intra) {
            $row[56] = $this->round2($igst / 2);
            $row[57] = $this->round2($igst / 2);
        } else {
            $row[58] = $this->round2($igst);
        }
        $row[66] = $this->round2($gross);
        $row[75] = $this->round2($paybleAmount);
        if ($intra) {
            $row[76] = $this->round2(($paybleAmount * 9) / 100);
            $row[77] = $this->round2(($paybleAmount * 9) / 100);
        } else {
            $row[78] = $this->round2(($paybleAmount * 18) / 100);
        }
        $row[84] = $this->round2($incTaxpaybleAmount);

        return $row;
    }

    /**
     * Document Date comes from Supplier_Ship_Date (rsc_col_2, DDMMYYYY), which is the
     * real invoice date and always matches the date in the SIPL_<yyyymmdd>_<no> file name.
     * A malformed value is passed through so GO4GST rejects the import instead of the
     * e-invoice being stamped with a wrong date.
     */
    private function formatShipDate(string $raw): string
    {
        $s = trim($raw);
        if (strlen($s) === 8 && ctype_digit($s)) {
            return substr($s, 0, 2) . '/' . substr($s, 2, 2) . '/' . substr($s, 4, 4);
        }
        return $s;
    }

    private function trim30(string $s): string
    {
        $s = trim($s);
        if (function_exists('mb_substr')) {
            return mb_substr($s, 0, self::TEXT_MAX);
        }
        return substr($s, 0, self::TEXT_MAX);
    }

    private function state2(string $s): string
    {
        return str_pad(trim($s), 2, '0', STR_PAD_LEFT);
    }

    private function num($v): float
    {
        if (is_numeric($v)) {
            return (float) $v;
        }
        $s = str_replace(',', '', trim((string) $v));
        return is_numeric($s) ? (float) $s : 0.0;
    }

    private function round2(float $d): string
    {
        return number_format($d, 2, '.', '');
    }

    private function numText($v): string
    {
        $d = $this->num($v);
        if (floor($d) == $d) {
            return (string) (int) $d;
        }
        return rtrim(rtrim(number_format($d, 2, '.', ''), '0'), '.');
    }

    /**
     * @param  string[]  $fields
     */
    private function csvLine(array $fields): string
    {
        $out = [];
        foreach ($fields as $f) {
            $s = (string) $f;
            if (strpbrk($s, ",\"\r\n") !== false) {
                $out[] = '"' . str_replace('"', '""', $s) . '"';
            } else {
                $out[] = $s;
            }
        }
        return implode(',', $out);
    }
}
