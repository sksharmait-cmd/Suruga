<?php

namespace App\Services;

/**
 * Parses the 34-column MOSSIND_AR-style CSV into row arrays shaped like rst_excel_row_data.
 * Shared by DB import path and GO4GST_SKIP_DB (in-memory) path.
 *
 * Validation is stricter than the web upload on purpose: the 139-column template carries
 * invoice level totals, so a file holding more than one invoice or more than one ECAL code
 * would silently produce an e-invoice with the wrong totals.
 */
class MossCsvParser
{
    /**
     * @return array{0:true|string,1:array<int,array<string,mixed>>}
     *         [true, rows] or [errorMessage, []]
     */
    public function parseFile(string $path): array
    {
        $fh = fopen($path, 'r');
        if ($fh === false) {
            return ['Cannot read uploaded CSV.', []];
        }

        $rows = [];
        $kn = 0;
        $total = 0.0;
        $invoiceNos = [];
        $ecalCodes = [];

        while (($line = fgetcsv($fh)) !== false) {
            $kn++;
            if ($kn < 2) {
                continue; // header
            }
            if ($this->isEmptyLine($line)) {
                continue;
            }
            if (!isset($line[2])) {
                fclose($fh);
                return ['Oops! ECAL Customer Code is missing.', []];
            }
            $code = strtoupper(trim((string) $line[2]));
            if ($code !== 'H' && $code !== 'K' && $code !== 'M') {
                fclose($fh);
                return ['Oops! ECAL Customer Code is missing.', []];
            }
            $ecalCodes[$code] = true;

            $invoiceNo = trim((string) ($line[0] ?? ''));
            if ($invoiceNo === '') {
                fclose($fh);
                return ["Row {$kn}: Forwarder Invoice No is empty.", []];
            }
            $invoiceNos[$invoiceNo] = true;

            $shipDate = trim((string) ($line[1] ?? ''));
            if (!$this->isValidDdMmYyyy($shipDate)) {
                fclose($fh);
                return ["Row {$kn}: Supplier Ship Date '{$shipDate}' is not a valid DDMMYYYY date.", []];
            }

            $amount = trim((string) ($line[13] ?? ''));
            if ($amount === '' || !is_numeric(str_replace(',', '', $amount))) {
                fclose($fh);
                return ["Row {$kn}: Total Amount '{$amount}' is not a number.", []];
            }
            $total += (float) str_replace(',', '', $amount);

            $rows[] = $this->lineToRow($line);
        }
        fclose($fh);

        if (count($rows) === 0) {
            return ['CSV has no data rows.', []];
        }
        if (count($invoiceNos) > 1) {
            return [
                'CSV holds more than one invoice (' . implode(', ', array_keys($invoiceNos)) .
                '). Import one invoice at a time.',
                [],
            ];
        }
        if (count($ecalCodes) > 1) {
            return [
                'CSV holds more than one ECAL Customer Code (' . implode(', ', array_keys($ecalCodes)) .
                '). Each invoice must have a single buyer.',
                [],
            ];
        }
        if (round($total, 2) <= 0.0) {
            return ['Invoice total is 0. Check the Total Amount column.', []];
        }

        return [true, $rows];
    }

    /**
     * @param  array<int,mixed>  $line
     * @return array<string,mixed>
     */
    public function lineToRow(array $line): array
    {
        $data = [];
        for ($i = 0; $i <= 33; $i++) {
            $c = $i + 1;
            $column = 'rsc_col_' . $c;
            if (!array_key_exists($i, $line)) {
                $data[$column] = null;
                continue;
            }
            if ($column === 'rsc_col_3') {
                $v = strtoupper(trim((string) $line[$i]));
                $data[$column] = ($v === 'H' || $v === 'K' || $v === 'M') ? $v : 'H';
            } else {
                $data[$column] = $line[$i];
            }
        }
        // Seller defaults (same DB column defaults on rst_excel_row_data)
        $data['surg_gst'] = '06AAPCS3407B1ZM';
        $data['surg_legal_name'] = 'SURUGA INDIA PRIVATE LIMITED';
        $data['surg_trade_ame'] = 'SURUGA INDIA PRIVATE LIMITED';
        $data['surg_addr1'] = 'PLOT NO - 31, ELECTRONIC CITY,SEC-18,';
        $data['surg_addr2'] = 'Udyog Vihar, Phase IV';
        $data['surg_location'] = 'GURGAON, HARYANA';
        $data['surg_pincode'] = '122016';
        $data['surg_state'] = '06';
        $data['surg_phone_number'] = '8588856860';
        $data['surg_email'] = 'liju_ps.s0@misumi.co.jp';
        return $data;
    }

    /**
     * Supplier_Ship_Date is DDMMYYYY and becomes the Document Date of the e-invoice,
     * so a malformed value has to stop the import rather than reach GO4GST.
     */
    private function isValidDdMmYyyy(string $s): bool
    {
        if (strlen($s) !== 8 || !ctype_digit($s)) {
            return false;
        }
        return checkdate(
            (int) substr($s, 2, 2),
            (int) substr($s, 0, 2),
            (int) substr($s, 4, 4)
        );
    }

    /**
     * @param  array<int,mixed>  $line
     */
    private function isEmptyLine(array $line): bool
    {
        foreach ($line as $v) {
            if (trim((string) $v) !== '') {
                return false;
            }
        }
        return true;
    }
}
