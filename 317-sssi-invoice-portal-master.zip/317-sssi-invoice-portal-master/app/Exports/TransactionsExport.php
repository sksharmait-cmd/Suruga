<?php

namespace App\Exports;

use App\Models\Transaction;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\WithColumnFormatting;

class TransactionsExport implements FromView, WithColumnFormatting
{ 

    public function columnFormats(): array
    {
        return Go4gstColumnFormats::TEMPLATE;
    }

    public function view(): View
    {
        if(last(request()->segments())=='row'){
            $file = 'rowdata';
        }
        else{
            $file = 'template';
        }
        return view('adminview.'.$file, [
            'exceldata' => Transaction::all()->toArray()
        ]);
    }
    
}
