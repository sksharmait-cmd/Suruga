<?php

namespace App\Exports;

/**
 * Excel number formats used by the portal Template download (TransactionsExport)
 * and by the SSSi convert API. Keep in one place so the two files stay identical.
 */
class Go4gstColumnFormats
{
    public const TEMPLATE = [
        'H'  => '00',
        'U'  => '00',
        'Z'  => '00',
        'AP' => '00',
        'AY' => '0.00',
        'AZ' => '0.00',
        'BC' => '0.00',
        'BE' => '0.00',
        'BF' => '0.00',
        'BG' => '0.00',
        'BO' => '0.00',
        'BX' => '0.00',
        'BY' => '0.00',
        'BZ' => '0.00',
        'CA' => '0.00',
        'CG' => '0.00',
    ];
}
