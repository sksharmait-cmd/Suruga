<?php

namespace App\Exports;

use App\Services\Go4gstTemplateCsvBuilder;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithColumnFormatting;
use Maatwebsite\Excel\Concerns\WithHeadings;

/**
 * 139-column GO4GST template as XLSX.
 * Cell formats match TransactionsExport (portal Download Template).
 * Values come from Go4gstTemplateCsvBuilder (ship date, name ≤30).
 */
class Go4gstTemplateExport implements FromArray, WithHeadings, WithColumnFormatting
{
    /** @var array<int,array<int,mixed>> */
    private $rows;

    /**
     * @param  array<int,array<string,mixed>>  $exceldata
     */
    public function __construct(array $exceldata)
    {
        $this->rows = (new Go4gstTemplateCsvBuilder())->buildExcelRows($exceldata);
    }

    public function headings(): array
    {
        return Go4gstTemplateCsvBuilder::$headers;
    }

    public function array(): array
    {
        return $this->rows;
    }

    public function columnFormats(): array
    {
        return Go4gstColumnFormats::TEMPLATE;
    }
}
