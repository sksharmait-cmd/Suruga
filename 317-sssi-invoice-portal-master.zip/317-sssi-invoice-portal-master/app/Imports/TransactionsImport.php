<?php

namespace App\Imports;

use App\Models\Transaction;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithStartRow;

class TransactionsImport implements ToModel, WithStartRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function startRow(): int
    {
        return 2;
    }
    public function model(array $row)
    {
        for($i=0; $i<=33; $i++){
            $c=$i+1;
            if (array_key_exists($i,$row)){
                $column = 'rsc_col_'.$c;
                if($column=='rsc_col_3'){
                    $value = (strtoupper($row[$i])=='H' || strtoupper($row[$i])=='K' || strtoupper($row[$i])=='M')?strtoupper($row[$i]):'H';
                }else{
                    $value = $row[$i];
                }
                $dataIs[$column] = $value;
            }
        }
        return new Transaction($dataIs);
    }
}
