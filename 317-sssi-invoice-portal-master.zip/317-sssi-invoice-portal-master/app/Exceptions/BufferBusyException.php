<?php

namespace App\Exceptions;

use RuntimeException;

/**
 * Thrown when the rst_excel_row_data buffer lock could not be taken, meaning another
 * client is converting right now. Callers answer with HTTP 409 so SSSi Tool can retry.
 */
class BufferBusyException extends RuntimeException
{
    public function __construct(string $message = 'The rst_excel_row_data buffer is locked by another conversion.')
    {
        parent::__construct($message);
    }
}
