<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminLogin;
use App\Http\Controllers\AdminDashboard;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//////////////DEFAULT_ROUTES
/*Route::get('/', function () {
    return view('welcome');
});*/

//////////////////////CUSTOME_ROUTES

///////////LOGIN-AUTHENTICATION
Route::get('/', [AdminLogin::Class,'Login'])->middleware('isLogin');
Route::post('loginadmin', [AdminLogin::Class,'AdminLoginAuth']);

////////////AFTERLOGIN-ACCESSABLE
Route::prefix('admin')->middleware('isAdmin')->group(function(){
    ////////////////MASTER MENU
    Route::get('dashboard', [AdminDashboard::Class,'Dashboard'])->name('dashboard');
    Route::get('manage-import', [AdminDashboard::Class,'Importlist'])->name('importer');
    Route::get('manage-export', [AdminDashboard::Class,'Exportlist'])->name('exporter');
    Route::post('import-excel-file', [AdminDashboard::class, 'importExcel'])->name('importexcel');
    Route::get('export-excel-file/{type}/{data}', [AdminDashboard::class, 'exportExcel'])->name('exportexcel');

    //////LOGOUT
    Route::get('sign-out', [AdminDashboard::Class,'Logoutadmin'])->name('logout');
    
});