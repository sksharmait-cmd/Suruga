<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Go4gstApiController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Machine-facing endpoints (SSSi Tool). Web UI routes remain in web.php.
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::prefix('v1/go4gst')->middleware('api.key')->group(function () {
    Route::post('convert', [Go4gstApiController::class, 'convert']);
    Route::delete('rows', [Go4gstApiController::class, 'clearRows']);
    Route::post('import', [Go4gstApiController::class, 'importOnly']);
    Route::get('export', [Go4gstApiController::class, 'exportOnly']);
});
