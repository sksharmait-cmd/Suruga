-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 05, 2026 at 11:37 AM
-- Server version: 5.7.23-23
-- PHP Version: 8.1.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `surugd3n_invoice`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_100000_create_password_resets_table', 1),
(2, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 2),
(5, '2021_08_20_094435_create_transactions_tbl', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rst_administrator`
--

CREATE TABLE `rst_administrator` (
  `rsc_id` int(11) NOT NULL,
  `rsc_name` varchar(20) NOT NULL,
  `rsc_email` varchar(50) NOT NULL,
  `rsc_contact` varchar(100) NOT NULL,
  `rsc_address` varchar(200) NOT NULL,
  `rsc_password` varchar(500) NOT NULL,
  `rsc_type` int(11) NOT NULL DEFAULT '2',
  `rsc_status` varchar(10) NOT NULL DEFAULT 'Inactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rst_administrator`
--

INSERT INTO `rst_administrator` (`rsc_id`, `rsc_name`, `rsc_email`, `rsc_contact`, `rsc_address`, `rsc_password`, `rsc_type`, `rsc_status`) VALUES
(1, 'Suruga', 'surugaadmin', '', '', '$2y$10$5rAvz5cmM/QNjPIQQRoaHOOSaHTnhtJQ4qTkFnowC6cyTzWJVDjQa', 1, 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `rst_excel_row_data`
--

CREATE TABLE `rst_excel_row_data` (
  `rsc_id` int(22) NOT NULL,
  `rsc_col_1` text,
  `rsc_col_2` text,
  `rsc_col_3` text,
  `rsc_col_4` text,
  `rsc_col_5` text,
  `rsc_col_6` text,
  `rsc_col_7` text,
  `rsc_col_8` text,
  `rsc_col_9` text,
  `rsc_col_10` text,
  `rsc_col_11` text,
  `rsc_col_12` text,
  `rsc_col_13` text,
  `rsc_col_14` text,
  `rsc_col_15` text,
  `rsc_col_16` text,
  `rsc_col_17` text,
  `rsc_col_18` text,
  `rsc_col_19` text,
  `rsc_col_20` text,
  `rsc_col_21` text,
  `rsc_col_22` text,
  `rsc_col_23` text,
  `rsc_col_24` text,
  `rsc_col_25` text,
  `rsc_col_26` text,
  `rsc_col_27` text,
  `rsc_col_28` text,
  `rsc_col_29` text,
  `rsc_col_30` text,
  `rsc_col_31` text,
  `rsc_col_32` text,
  `rsc_col_33` text,
  `rsc_col_34` text,
  `rsc_col_35` text,
  `rsc_col_36` text,
  `rsc_col_37` text,
  `rsc_col_38` text,
  `rsc_col_39` text,
  `rsc_col_40` text,
  `rsc_col_41` text,
  `rsc_col_42` text,
  `rsc_col_43` text,
  `rsc_col_44` text,
  `rsc_col_45` text,
  `rsc_col_46` text,
  `rsc_col_47` text,
  `rsc_col_48` text,
  `rsc_col_49` text,
  `rsc_col_50` text,
  `rsc_col_51` text,
  `rsc_col_52` text,
  `rsc_col_53` text,
  `rsc_col_54` text,
  `rsc_col_55` text,
  `rsc_col_56` text,
  `rsc_col_57` text,
  `rsc_col_58` text,
  `rsc_col_59` text,
  `rsc_col_60` text,
  `rsc_col_61` text,
  `rsc_col_62` text,
  `rsc_col_63` text,
  `rsc_col_64` text,
  `rsc_col_65` text,
  `rsc_col_66` text,
  `rsc_col_67` text,
  `rsc_col_68` text,
  `rsc_col_69` text,
  `rsc_col_70` text,
  `rsc_col_71` text,
  `rsc_col_72` text,
  `rsc_col_73` text,
  `surg_gst` varchar(500) NOT NULL DEFAULT '06AAPCS3407B1ZM',
  `surg_legal_name` varchar(500) NOT NULL DEFAULT 'SURUGA INDIA PRIVATE LIMITED',
  `surg_trade_ame` varchar(500) NOT NULL DEFAULT 'SURUGA INDIA PRIVATE LIMITED',
  `surg_addr1` varchar(500) NOT NULL DEFAULT 'PLOT NO - 31, ELECTRONIC CITY,SEC-18,',
  `surg_addr2` varchar(500) NOT NULL DEFAULT 'Udyog Vihar, Phase IV',
  `surg_location` varchar(50) NOT NULL DEFAULT 'GURGAON, HARYANA',
  `surg_pincode` varchar(50) NOT NULL DEFAULT '122016',
  `surg_state` varchar(10) NOT NULL DEFAULT '06',
  `surg_phone_number` varchar(50) NOT NULL DEFAULT '8588856860',
  `surg_email` varchar(100) NOT NULL DEFAULT 'liju_ps.s0@misumi.co.jp',
  `rsc_status` varchar(10) NOT NULL DEFAULT 'Active',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rst_excel_row_data`
--

INSERT INTO `rst_excel_row_data` (`rsc_id`, `rsc_col_1`, `rsc_col_2`, `rsc_col_3`, `rsc_col_4`, `rsc_col_5`, `rsc_col_6`, `rsc_col_7`, `rsc_col_8`, `rsc_col_9`, `rsc_col_10`, `rsc_col_11`, `rsc_col_12`, `rsc_col_13`, `rsc_col_14`, `rsc_col_15`, `rsc_col_16`, `rsc_col_17`, `rsc_col_18`, `rsc_col_19`, `rsc_col_20`, `rsc_col_21`, `rsc_col_22`, `rsc_col_23`, `rsc_col_24`, `rsc_col_25`, `rsc_col_26`, `rsc_col_27`, `rsc_col_28`, `rsc_col_29`, `rsc_col_30`, `rsc_col_31`, `rsc_col_32`, `rsc_col_33`, `rsc_col_34`, `rsc_col_35`, `rsc_col_36`, `rsc_col_37`, `rsc_col_38`, `rsc_col_39`, `rsc_col_40`, `rsc_col_41`, `rsc_col_42`, `rsc_col_43`, `rsc_col_44`, `rsc_col_45`, `rsc_col_46`, `rsc_col_47`, `rsc_col_48`, `rsc_col_49`, `rsc_col_50`, `rsc_col_51`, `rsc_col_52`, `rsc_col_53`, `rsc_col_54`, `rsc_col_55`, `rsc_col_56`, `rsc_col_57`, `rsc_col_58`, `rsc_col_59`, `rsc_col_60`, `rsc_col_61`, `rsc_col_62`, `rsc_col_63`, `rsc_col_64`, `rsc_col_65`, `rsc_col_66`, `rsc_col_67`, `rsc_col_68`, `rsc_col_69`, `rsc_col_70`, `rsc_col_71`, `rsc_col_72`, `rsc_col_73`, `surg_gst`, `surg_legal_name`, `surg_trade_ame`, `surg_addr1`, `surg_addr2`, `surg_location`, `surg_pincode`, `surg_state`, `surg_phone_number`, `surg_email`, `rsc_status`, `created_at`, `updated_at`) VALUES
(93492, '7912', '4082026', 'H', NULL, NULL, 'ECONOMY OIL FREE SLIDE PLATE', 'E-MWF75-100', NULL, 'IND-D2260630088211', '100', 'PCS', '268', 'INR', '26800', NULL, NULL, NULL, '1060402', '82073000', '0', '4082026', '0', '0', '0', '0', '0', '0.12', '3216', '0.03', ' 96.48 ', '0', '0', '0', ' 3,312.48 ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '06AAPCS3407B1ZM', 'SURUGA INDIA PRIVATE LIMITED', 'SURUGA INDIA PRIVATE LIMITED', 'PLOT NO - 31, ELECTRONIC CITY,SEC-18,', 'Udyog Vihar, Phase IV', 'GURGAON, HARYANA', '122016', '06', '8588856860', 'liju_ps.s0@misumi.co.jp', 'Active', '2026-08-04 09:37:36', '2026-08-04 09:37:36');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name_on_card` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `card_no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exp_month` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exp_year` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cvv` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `rst_administrator`
--
ALTER TABLE `rst_administrator`
  ADD PRIMARY KEY (`rsc_id`);

--
-- Indexes for table `rst_excel_row_data`
--
ALTER TABLE `rst_excel_row_data`
  ADD PRIMARY KEY (`rsc_id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rst_administrator`
--
ALTER TABLE `rst_administrator`
  MODIFY `rsc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `rst_excel_row_data`
--
ALTER TABLE `rst_excel_row_data`
  MODIFY `rsc_id` int(22) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93493;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
